"""
@summary: Location of local configuration options
@author: CJ Grady
@contact: cjgrady [at] ku [dot] edu
@version: 1.0
@status: beta

@license: gpl2
@copyright: Copyright (C) 2013, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
import hashlib
import ConfigParser

# .............................................................................
def singleton(cls):
   """
   @summary: Creates singletons for all unique sets of arguments for a class
   """
   instances = {}
   def getInstance(*args, **kwargs):
      name = hashlib.md5(''.join([str(args), str(kwargs)])).hexdigest()
      if name not in instances:
         instances[name] = cls(*args, **kwargs)
      return instances[name]
   return getInstance

# .............................................................................
@singleton
class Config(object):
   """
   @summary: Lifemapper configuration object will read config.ini and store 
                values
   """
   def __init__(self, fn='/var/lm/code/common/config.ini'):
      self.fn = fn
      self.config = ConfigParser.ConfigParser()
      self.config.read(self.fn)
      if 'system' not in self.config.sections():
         self.getSysConfig()
      
   def get(self, section, item):
      return self.config.get(section, item)
   
   def getboolean(self, section, item):
      return self.config.getboolean(section, item)

   def getSysConfig(self):
      from collections import OrderedDict
      import platform
      import socket

      with open(self.fn, 'a') as f:
         f.write('\n[system]\n')
         f.write('Machine Name: {0}\n'.format(platform.node()))
         f.write('Machine IP: {0}\n'.format(socket.gethostbyname(socket.gethostname())))
         f.write('Architecture: {0}\n'.format(platform.processor()))
         f.write('OS: {0}\n'.format(platform.system()))
         
         try:
            meminfo = OrderedDict()
            with open('/proc/meminfo') as f2:
               for line in f2:
                  meminfo[line.split(':')[0]] = line.split(':')[1].strip()
            f.write('Total Memory: {0}\n'.format(meminfo['MemTotal']))

            x = 0
            f.write("CPU Info: \n")
            with open('/proc/cpuinfo') as f2:
               for line in f2:
                  if line.strip():
                     if line.rstrip('\n').startswith('model name'):
                        f.write("  {0} -{1}\n".format(x, line.rstrip('\n'
                                                              ).split(':')[1]))
                        x += 1
         except:
            pass

         f.write("Python Version: {0}\n".format(platform.python_version()))
         f.write("Linux Version: {0}\n".format(' '.join(
                                               platform.linux_distribution())))
         
      self.config = ConfigParser.SafeConfigParser()
      self.config.read(self.fn)
      
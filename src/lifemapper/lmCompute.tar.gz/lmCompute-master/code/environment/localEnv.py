"""
@summary: Contains the Lifemapper cluster environment class
@author: CJ Grady
@version: 2.0
@status: beta

@license: gpl2
@copyright: Copyright (C) 2013, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
import os

from environment.environmentMethods import _EnvironmentMethods
from common.config import Config
from common.jobClient import LmJobClient

# .............................................................................
class LocalEnv(_EnvironmentMethods):
   """
   @summary: Lifemapper cluster environment methods.
   """
   # ..................................
   def __init__(self):
      """
      @summary: Constructor
      """
      self.cl = LmJobClient()
      self.config = Config()
   
   # ..................................
   def createLink(self, fromPath, toPath):
      """
      @summary: Creates a link between two paths
      @param fromPath: The new file / directory
      @param toPath: The file / directory that it points to
      """
      if not os.path.islink(fromPath):
         os.symlink(toPath, fromPath)

   # ..................................
   def getApplicationPath(self):
      """
      @summary: Gets the application path for this environment
      @return: The base path for applications in this environment
      @rtype: String
      """
      return self.config.get('environment', 'APP_PATH')
   
   # ..................................
   def getJobDataPath(self):
      """
      @summary: Gets the job input data path for this environment
      @return: The base path for job input data in this environment
      @rtype: String
      """
      return self.config.get('environment', 'JOB_DATA_PATH')
   
   # ..................................
   def getJobOutputPath(self):
      """
      @summary: Gets the job output data path for this environment
      @return: The base path for job output data in this environment
      @rtype: String
      """
      return self.config.get('environment', 'JOB_OUTPUT_PATH')
   
   # ..................................
   def postJob(self, jobType, jobId, content, contentType, component):
      """
      @summary: Posts (part of) a job via the environment
      @param jobType: The type of job being posted
      @param jobId: The id of the job being posted
      @param content: The content of the post
      @param contentType: The MIME-type of the content
      @param component: The part of the job being posted (data, log, error, etc)
      """
      return self.cl.postJob(jobType, jobId, content, contentType, component)
   
   # ..................................
   def requestJob(self, validTypes=[], parameters={}):
      """
      @summary: Requests a job to run
      @param validTypes: A list of the job types this environment can process
      @param parameters: An optional dictionary of parameters specifying a 
                            subset of jobs that this environment is willing to 
                            compute
      """
      return self.cl.requestJob(jobTypes=validTypes, parameters=parameters)

   # ..................................
   def updateJob(self, jobType, jobId, status, progress):
      """
      @summary: Updates the job status information in whatever manages it for
                   this environment
      @param status: The new status of the job
      @param progress: The new progress of the job
      @return: Value indicating success
      @rtype: Boolean
      """
      return self.cl.updateJob(jobType, jobId, status, progress)
   
   
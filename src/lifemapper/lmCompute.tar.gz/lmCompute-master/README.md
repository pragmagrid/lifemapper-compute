lmCompute
=========

The Lifemapper compute package interacts with the Lifemapper job server.  It 
provides a pluggable framework for different types of Lifemapper jobs.  The 
base compute package includes a client for interacting with the job server and
comes with two computational job plug-ins for openModeller and MaxEnt 
Lifemapper computation jobs.

In any other plug-ins become available, they can be dropped into the "plugins"
directory where they will be automatically registered with the framework.

-----

Configuration
=============
Edit the values of code/common/config.ini to reflect your configuration

Contact section:
The values in the contact section reflect who should be contacted if there are
problems with the compute installation.

INSTITUTION_NAME - The name of the institution where this installation is held
ADMIN_NAME - The name of the system administrator to contact
ADMIN_EMAIL - The email address of the administrator
LOCAL_MACHINE_ID - An identifier for this machine.

Environment section:

The values in the environment section of the configuration file indicate where
data should be stored, where code can be found, and your Lifemapper user c
configuration

PLUGINS_DIR - The location of the lmCompute plugins directory
APP_PATH - Where binaries for the plugins are stored
JOB_DATA_PATH - A location where job input data can be written
JOB_OUTPUT_PATH - A location where job output data can be written
LM_USER_JOB - A comma-separated list of Lifemapper users to run jobs for

Commands section:

The values in the section are for commands that may be called from multiple
plugins

GDALINFO_CMD - Indicates how gdalinfo should be called


Plugins:
openModeller section:

The values in the openModeller section are constants related to your 
installation of openModeller

DEFAULT_LOG_LEVEL - The log level for openModeller to user
OM_MODEL_CMD - Command to call 'om_model' (assumed to be in APP_PATH)
OM_PROJECT_CMD - Command to call 'om_project' (assumed to be in APP_PATH)
OM_VERSION - The version of openModeller installed

MaxEnt section:

The values in the maxent section are constants related to your installation of
MaxEnt

JAVA_CMD - Command to call java (assumed to be in APP_PATH)
ME_CMD - The name of the maxent jar file
MDL_TOOL - The name of the Maxent model tool
PRJ_TOOL - The name of the Maxent projection tool
ME_VERSION - The version of Maxent installed

Options section:

The options section contains values used in the plugins

Store Log Files - Should the log files be kept
Log Storage Location - Common directory where to ship the log files


System section:

This section is automatically generated the first time the configuration file 
is read by a job.  It includes information about the CPUs and memory on your 
machine as well as your operating system, etc.
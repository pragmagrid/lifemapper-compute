#!/bin/bash

python2.7 /var/lm/code/common/controller.py


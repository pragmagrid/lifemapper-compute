#!/bin/bash

$NODE_PYTHON $LM_NODE_CODE_LOCATION/common/controller.py 1

#!/bin/bash

$PYTHON $LM_SCRIPTS_PATH/jobSubmitter.py $LM_JOB_SUBMITTER_CONFIG stop

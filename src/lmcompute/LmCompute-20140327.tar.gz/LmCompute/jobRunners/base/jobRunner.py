"""
@summary: Module containing job runner base class
@author: CJ Grady
@version: 2.0
@status: beta

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
import logging
from logging.handlers import RotatingFileHandler
import os

LOG_FORMAT = "%(asctime)s %(levelname)-8s %(message)s"
# Date format for log dates
LOG_DATE_FORMAT = '%d %b %Y %H:%M'

# .............................................................................
class JobRunner(object):
   """
   @summary: Job Runner base class. Job runners are responsible for running a 
                process required to execute some job.
   """
   # ..................................
   def __init__(self, job, env):
      self.job = job
      self.env = env
      self.metrics = {}
      
   # ..................................
   def run(self):
      raise Exception, "Run method must be declared in a sub-class"
   
   # ..................................
   def _initLogger(self, name, filename):
      self.log = logging.getLogger(name)
      self.log.setLevel(logging.DEBUG)
      fileLogHandler = RotatingFileHandler(self.jobLogFile)
      fileLogHandler.setLevel(self.log.level)
      formatter = logging.Formatter(LOG_FORMAT, LOG_DATE_FORMAT)
      fileLogHandler.setFormatter(formatter)
      self.log.addHandler(fileLogHandler)

   # ..................................
   def _logSystemInformation(self):
      try:
         self.log.debug("-------------------------------------------------------")
         self.log.debug("Machine Name: {0}".format(self.env.config.get('system', 'Machine Name')))
         self.log.debug("Machine IP: {0}".format(self.env.config.get('system', 'Machine IP')))
         self.log.debug("Architecture: {0}".format(self.env.config.get('system', 'Architecture')))
         self.log.debug("OS: {0}".format(self.env.config.get('system', 'OS')))
         self.log.debug("Total Memory: {0}".format(self.env.config.get('system', 'Total Memory')))
         self.log.debug("CPU Info: {0}".format(self.env.config.get('system', 'CPU Info')))
         self.log.debug("Python Version: {0}".format(self.env.config.get('system', 'Python Version')))
         self.log.debug("Linux Version: {0}".format(self.env.config.get('system', 'Linux Version')))
         self.log.debug("-------------------------------------------------------")
      except:
         pass

   # ..................................
   def writeMetrics(self, jobType, jobId):
      """
      @summary: Writes out the metrics of the job
      """
      if self.env.config.getboolean('metrics', 'Store Metrics'):
         fn = os.path.join(self.env.config.get('metrics', 'Metrics Storage Directory'),
                           "job-%s-%s.metrics" % (jobType, jobId))
         if len(self.metrics.keys()) > 0:
            with open(fn, 'w') as outFile:
               for key in self.metrics.keys():
                  outFile.write("%s: %s\n" % (key, str(self.metrics[key])))
      
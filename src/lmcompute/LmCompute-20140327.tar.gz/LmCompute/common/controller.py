"""
@summary: Module containing classes for controlling job submission
@author: CJ Grady
@version: 1.0
@status: beta

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
from LmCompute.common.jobTypes import JOB_TYPES
from LmCompute.common.lmConstants import JobStatus
from LmCompute.environment.localEnv import LocalEnv
from LmCompute.environment.testEnv import TestEnv

class JobController(object):
   """
   @summary: Controls how jobs are ran in this environment.  
   """
   
   # ......................................
   def __init__(self, env, numJobs=1):
      self.env = env
      self.numJobs = numJobs
   
   #.......................................
   def run(self, jobTypes=JOB_TYPES.keys()):
      for _ in range(self.numJobs):
         j = self.env.requestJob(validTypes=jobTypes, 
                                 parameters={'users' : self.env.config.get(
                                                'environment', 'LM_USER_JOB')})
         if j is not None:
            print "Job:", j.jobId
            print "Job type:", j.processType
            from LmCompute.common.lmXml import serialize, tostring
            print tostring(serialize(j))
            self.env.updateJob(j.processType, j.jobId, JobStatus.PULL_COMPLETE, 
                                                                          None)
            jr = JOB_TYPES[int(j.processType)]['constructor'](j, self.env)
            jr.run()
      
# .............................................................................
def runTests():
   print "Test Mode"
   env = TestEnv()
   jc = JobController(env)
   jts = [110, 120, 210, 220, 310, 405]
   for jt in jts:
      jc.run(jobTypes=[jt])
      
   
# .............................................................................
if __name__ == "__main__":
   import sys
   
   if len(sys.argv) > 1 and sys.argv[1].lower() == 'test':
      runTests()
   else:
      try:
         numJobs = int(sys.argv[1])
      except:
         numJobs = 1
      env = LocalEnv()
      jc = JobController(env, numJobs=numJobs)
      jc.run()
   
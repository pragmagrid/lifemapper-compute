"""
@summary: Module containing GBIF functions
@author: Aimee Stewart
@version: 3.1
@status: beta

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
import csv
import json
import os
from osgeo import ogr, osr
import urllib2
import zipfile

from LmCompute.plugins.sdm.gbif.constants import GBIF_REST_URL, \
                                       GBIF_OCCURRENCE_SERVICE, \
                                       GBIF_DOWNLOAD_COMMAND, \
                                       GBIF_OCCURRENCE_URL, \
                                       GBIF_RESPONSE_STATUS_KEY, \
                                       GBIF_RESPONSE_LINK_KEY, \
                                       GBIF_RESPONSE_SIZE_KEY, \
                                       GBIF_RESPONSE_COUNT_KEY, \
                                       GBIF_RESPONSE_STATUS_COMPLETE_VALUE, \
                                       GBIF_FIELD_METADATA_FILENAME, \
                                       GBIF_OCCURRENCE_FILENAME, \
                                       DWC_NAMESPACE, DWC_PREFIX, \
                                       DWC_TRANSLATIONS, LM_ADD_FIELDS, \
                                       DWC_X_FIELD, DWC_Y_FIELD, DWC_ID_FIELD, \
                                       LM_WKT_FIELD, GBIF_LINK_FIELD, \
                                       SHAPEFILE_MAX_STRINGSIZE

# .............................................................................
# PRIVATE
# .............................................................................
def _getGBIFResults(url):
   status = link = count = size = None
   try:
      response = urllib2.urlopen(url).read()
   except Exception, e:
      raise e
   outDict = json.loads(response)
   if outDict.has_key(GBIF_RESPONSE_STATUS_KEY):
      status = outDict[GBIF_RESPONSE_STATUS_KEY]
   if outDict.has_key(GBIF_RESPONSE_LINK_KEY):
      link = outDict[GBIF_RESPONSE_LINK_KEY]
   if outDict.has_key(GBIF_RESPONSE_COUNT_KEY):
      count = outDict[GBIF_RESPONSE_COUNT_KEY]
   if outDict.has_key(GBIF_RESPONSE_SIZE_KEY):
      size = outDict[GBIF_RESPONSE_SIZE_KEY]
   return status, link, count, size
     
# ...............................................
def _getDownloadFile(downloadLink, tempPath):
   """
   """
   tmpFname = os.path.join(tempPath, os.path.basename(downloadLink))
   try:
      response = urllib2.urlopen(downloadLink)
   except Exception, e:
      print('Error code = %s, reason = %s' % (str(e.code), str(e.reason)))
      raise e
   
   try:
      # Open local file for writing
      with open(tmpFname, "wb") as f:
         f.write(response.read())

   #handle errors
   except Exception, e:
      print('Error code = %s, reason = %s' % (str(e.code), str(e.reason)))
      raise e
   return tmpFname

# ...............................................
def _extractZipfile(zipFname, tempPath):
   zf = zipfile.ZipFile(zipFname)
   for zipinfo in zf.infolist():
      basename = os.path.basename(zipinfo.filename)
      if basename in (GBIF_FIELD_METADATA_FILENAME, GBIF_OCCURRENCE_FILENAME):
         zf.extract(zipinfo, tempPath)
         
# ...............................................
def _getDWCIndicesFromMetadata(metafname):
   import xml.etree.ElementTree as ET
   metaIdxs = {}
   tree = ET.parse(metafname)
   root = tree.getroot()
   for fld in root.iter('%sfield' % DWC_NAMESPACE):
      if fld.attrib['term'].startswith(DWC_PREFIX):
         idx = int(fld.attrib['index'])
         dwcTerm = fld.attrib['term'][len(DWC_PREFIX):]
         metaIdxs[idx] = dwcTerm
         if dwcTerm == DWC_X_FIELD:
            xIdx = idx
         elif dwcTerm == DWC_Y_FIELD:
            yIdx = idx
         elif dwcTerm == DWC_ID_FIELD:
            idIdx = idx
   return metaIdxs, xIdx, yIdx, idIdx
         
# ...............................................
def _addDWCLayer(newDataset, metaIdxs, xIdx, yIdx):
   spRef = osr.SpatialReference()
   spRef.ImportFromEPSG(4326)

   newLyr = newDataset.CreateLayer('points', geom_type=ogr.wkbPoint, srs=spRef)
   if newLyr is None:
      raise Exception('Layer creation failed')
   
   for idx, dwcTerm in metaIdxs.iteritems():
      fldname, fldtype = DWC_TRANSLATIONS[dwcTerm]
      fldDef = ogr.FieldDefn(fldname, fldtype)
      if (fldname.endswith('name') and fldtype == ogr.OFTString):
         fldDef.SetWidth(SHAPEFILE_MAX_STRINGSIZE)
      returnVal = newLyr.CreateField(fldDef)
      if returnVal != 0:
         raise Exception('Failed to create field %s' % fldname)
   for fldname, fldtype in LM_ADD_FIELDS.iteritems():
      fldDef = ogr.FieldDefn(fldname, fldtype)
      returnVal = newLyr.CreateField(fldDef)
   return newLyr

# ...............................................
def _fillFeature(feat, line, metaIdxs, xIdx, yIdx, idIdx):
   """
   @note: This *should* return the modified feature
   """
   # Set LM added fields, geometry, geomwkt
   wkt = 'POINT (%s  %s)' % (str(line[xIdx]), str(line[yIdx]))
   feat.SetField(LM_WKT_FIELD, wkt)
   geom = ogr.CreateGeometryFromWkt(wkt)
   feat.SetGeometryDirectly(geom)
   # Set LM added field GBIF url
   pturl = '%s/%s' % (GBIF_OCCURRENCE_URL, str(line[idIdx]))
   feat.SetField(GBIF_LINK_FIELD, pturl)
   
   # Add values out of the line of data
   for idx, dwcTerm in metaIdxs.iteritems():
      fldname = DWC_TRANSLATIONS[dwcTerm][0]
      val = line[idx]
      if val is not None and val != 'None':
         feat.SetField(fldname, val)

# ...............................................
def _rewriteOccurrences(occfname, metafname, outfname, appPath="", 
                        overwrite=True):
   drv = ogr.GetDriverByName('ESRI Shapefile')
   if os.path.isfile(outfname):
      if overwrite:
         drv.DeleteDataSource(outfname)
      else:
         raise Exception('Shapefile %s exists' % outfname)
      
   newDs = drv.CreateDataSource(outfname)
   if newDs is None:
      raise Exception('Dataset creation failed for %s' % outfname)
   
   metaIdxs, xIdx, yIdx, idIdx = _getDWCIndicesFromMetadata(metafname)
   newLyr = _addDWCLayer(newDs, metaIdxs, xIdx, yIdx)
   lyrDef = newLyr.GetLayerDefn()
   
   try:
      infile = open(occfname, 'r')
      reader = csv.reader(infile, delimiter='\t')
      for line in reader:
         # Get only DWC fields
         if reader.line_num > 1:
            feat = ogr.Feature(lyrDef)
            try:
               _fillFeature(feat, line, metaIdxs, xIdx, yIdx, idIdx)
            except Exception, e:
               print 'Failed to fillOGRFeature, e = %s' % str(e)
               raise e
            else:
               # Create new feature, setting FID, in this layer
               newLyr.CreateFeature(feat)
               feat.Destroy()
      infile.close()
      # Closes and flushes to disk
      newDs.Destroy()
   except Exception, e:
      print 'Unable to read or write data (%s)' % str(e)
   print('Closed/wrote dataset %s' % outfname)

#    try:
#       shpTreeCmd = os.path.join(appPath, "shptree")
#       retcode = subprocess.call([shpTreeCmd, "%s" % outfname])
#       if retcode != 0: 
#          print 'Unable to create shapetree index on %s' % outfname
#    except Exception, e:
#       print 'Unable to create shapetree index on %s: %s' % (outfname, str(e))
               
# ...............................................
def _signInToGBIF(gbifUser, gbifPwd):
   # create a password manager
   passwordMgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
   passwordMgr.add_password('GBIF', GBIF_REST_URL, gbifUser, gbifPwd)
   handler = urllib2.HTTPBasicAuthHandler(passwordMgr)
   
   # Create and Install opener - now all calls to urllib2.urlopen use our opener.
   opener = urllib2.build_opener(handler)
   urllib2.install_opener(opener)

# .............................................................................
# PUBLIC
# .............................................................................
def isGBIFDownloadReady(gbifUser, gbifPwd, gbifDownloadKey):
   """
   @summary: Returns a boolean value indicating if the GBIF occurrence data is
                ready to be downloaded
   @param gbifDownloadKey: The key of the data set to download
   @return: Boolean value indicating if the data set is ready for download
   @rtype: if ready, returns a string containing the download link for the data;
           if not ready, returns None 
   """
   _signInToGBIF(gbifUser, gbifPwd)
   url = '%s/%s/%s/%s' % (GBIF_REST_URL, GBIF_OCCURRENCE_SERVICE, 
                          GBIF_DOWNLOAD_COMMAND, gbifDownloadKey)
   status, link, count, size = _getGBIFResults(url)
   if status == GBIF_RESPONSE_STATUS_COMPLETE_VALUE:
      return link
   else:
      return None

# .............................................................................
def retrieveGBIFData(gbifDownloadKey, basePath, appPath=""):
   """
   @summary: Retrieves a GBIF data set and saves it to a shapefile in the 
                specified location
   @param gbifDownloadKey: The key of the data set to be downloaded
   @param basePath: A directory where the shapefile should be stored
   @precondition: The GBIF data set is ready to be downloaded
   @return: The name of the file where the data is stored (.shp extension)
   @rtype: String
   """
   fname = _getDownloadFile(gbifDownloadKey, basePath)
   _extractZipfile(fname, basePath)
   
   occfname = os.path.join(basePath, GBIF_OCCURRENCE_FILENAME)
   metafname = os.path.join(basePath, GBIF_FIELD_METADATA_FILENAME)
   shapefileName = os.path.join(basePath, 
              os.path.splitext(os.path.basename(gbifDownloadKey))[0]  + '.shp')
   _rewriteOccurrences(occfname, metafname, shapefileName, appPath=appPath)
   return shapefileName

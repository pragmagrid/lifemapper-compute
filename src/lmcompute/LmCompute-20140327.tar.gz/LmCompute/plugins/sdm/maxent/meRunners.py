"""
@summary: Module containing the job runners for Maximum Entropy models and 
             projections
@author: CJ Grady
@version: 3.0
@status: alpha

@note: Commands are for maxent library version 3.3.3e
@note: Commands may be backwards compatible

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
import os

from LmCompute.common.lmConstants import JobStatus
from LmCompute.plugins.sdm.maxent.constants import PARAMETERS
from LmCompute.common.layerManager import convertLayerFormat, LayerManager
from LmCompute.jobRunners.base.applicationRunner import ApplicationRunner

# .............................................................................
class MEModelRunner(ApplicationRunner):
   """
   @summary: MaxEnt model job runner
   """
   PROCESS_TYPE = 110
   # ...................................
   def _buildCommand(self):
      """
      @summary: Builds the command that will generate a model
      @return: A bash command to run
      
      @note: MaxEnt version 3.3.3e
      """
      baseCmd = "{0}{1} {0}{2} {3}".format(self.env.getApplicationPath(), 
                                    self.env.config.get('maxent', 'JAVA_CMD'), 
                                    self.env.config.get('maxent', 'ME_CMD'), 
                                    self.env.config.get('maxent', 'MDL_TOOL'))
      samples = "-s {0}".format(self.samplesFile)
      envParams = "-e {0}".format(self.jobLayerDir)
      outputParams = "-o {0}".format(self.jobOutputDir)
      algoOptions = getAlgorithmOptions(self.job.algorithm)
      options = "nowarnings autorun -z"
      # Application path, me command, model tool
      cmd = "{0} {1} {2} {3} {4} {5}".format(baseCmd, samples, envParams, 
                                            outputParams, algoOptions, options)
      return cmd
   
   # ...................................
   def _checkApplication(self):
      """
      @summary: Checks the MaxEnt output files to get the progress and 
                   status of the running model.
      """
      pass
   
   # ...................................
   def _checkOutput(self):
      """
      @summary: Checks the output of MaxEnt to see if any errors occurred
      """
      pass
   
   # ...................................
   def _cleanUp(self):
      """
      @summary: Cleans up after a job has completed.  This should deleting all
                   files created by the job that do not need to be kept on the
                   node.
      """
      try:
         self.writeMetrics(self.PROCESS_TYPE, self.job.jobId)
      except:
         print "Failed to write metrics"
      
      try:
         self.log.debug("Job end time: %s" % self.endTime)
         import shutil
         if self.env.config.getboolean('options', 'Store Log Files'):
            shutil.move(self.jobLogFile, os.path.join(
                        self.env.config.get('options', 'Log Storage Location'), 
                        os.path.basename(self.jobLogFile)))
         shutil.rmtree(self.jobOutputDir)#, ignore_errors=True)
      except Exception, e:
         self.log.debug("Failed in cleanup: %s" % str(e))

   # ...................................
   def _initializeJob(self):
      """
      @summary: Initializes a model to be ran by MaxEnt
      """
      self.metrics['jobId'] = self.job.jobId
      self.metrics['algorithm'] = 'MAXENT'
      self.metrics['processType'] = self.PROCESS_TYPE
      
      self.dataDir = self.env.getJobDataPath()
      self.jobOutputDir = os.path.join(self.env.getJobOutputPath(), 
                       "job-{0}-{1}".format(self.PROCESS_TYPE, self.job.jobId))
      self.jobLayerDir = os.path.join(self.jobOutputDir, 'layers')
      self.samplesFile = os.path.join(self.jobOutputDir, 'samples.csv')
      self.lambdasFile = os.path.join(self.jobOutputDir, '{0}.lambdas'.format(
                                self.job.points.displayName.replace(' ', '_')))
      
      if not os.path.exists(self.jobLayerDir):
         os.makedirs(self.jobLayerDir)
      
      self.jobLogFile = "%s/jobLog-%s.log" % (self.jobOutputDir, self.job.jobId)
      
      self._initLogger('job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId), 
                                                               self.jobLogFile)

      # Logging
      self.log.debug("Job start time: %s" % self.startTime)
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Job Id: %s" % self.job.jobId)
      self.log.debug("User Id: %s" % self.job.userId)
      try:
         self.log.debug("Parent URL: %s" % self.job.parentUrl)
      except:
         pass
      try:
         self.log.debug("Object URL: %s" % self.job.url)
      except:
         pass
      self.log.debug("Institution: %s" % self.env.config.get('contact', 
                                                           'INSTITUTION_NAME'))
      self.log.debug("Admin: %s" % self.env.config.get('contact', 'ADMIN_NAME'))
      self.log.debug("Admin Email: %s" % self.env.config.get('contact', 
                                                                'ADMIN_EMAIL'))
      self.log.debug("Local Machine ID: %s" % self.env.config.get('contact', 
                                                           'LOCAL_MACHINE_ID'))
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Process Id: %s" % os.getpid())
      self.log.debug("-------------------------------------------------------")
      self.log.debug("MaxEnt Version: %s" % self.env.config.get('maxent', 
                                                                 'ME_VERSION'))
      self.log.debug("-------------------------------------------------------")
      self._logSystemInformation()

      # Layers
      handleLayers(self.job.layers, self.env, self.dataDir, self.jobLayerDir)
      # Points
      self._writePoints()
      
   # .......................................
   def _push(self):
      """
      @summary: Pushes the results of the job to the job server
      """
      component = "model"
      contentType = "text/plain"
      content = open(self.lambdasFile).read()
      self.status = JobStatus.PUSH_REQUESTED
      self._update()
      try:
         self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, 
                                                        contentType, component)
         try:
            self._pushPackage()
         except Exception, e:
            print str(e)
            self.log.debug("Failed to push package: %s" % str(e))
      except Exception, e:
         print str(e)
         try:
            self.log.debug(str(e))
         except Exception, e: # Log not initialized
            print str(e)
         self.status = JobStatus.PUSH_FAILED
         self._update()
   
   # ...................................
   def _pushPackage(self):
      """
      @summary: Pushes the entire package back to the job server
      @note: Does not push back layers directory
      """
      from StringIO import StringIO
      import zipfile

      component = "package"
      contentType = "application/zip"
      
      outStream = StringIO()
      zf = zipfile.ZipFile(outStream, 'w', allowZip64=True)
      for base, _, files in os.walk(self.jobOutputDir):
         if base.find('layers') == -1:
            for f in files:
               if f.find('.asc') == -1:
                  zf.write(os.path.join(base, f), 
                           os.path.relpath(os.path.join(base, f), 
                                           self.jobOutputDir))
      zf.close()      
      outStream.seek(0)
      content = outStream.getvalue()      
      self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, contentType,
                                                                     component)
   
   # ...................................
   def _writePoints(self):
      """
      @summary: Writes out the points of the job in a format MaxEnt can read
      """
      f = open(self.samplesFile, 'w')
      f.write("Species, X, Y\n")
      for pt in self.job.points:
         f.write("{0}, {1}, {2}\n".format(self.job.points.displayName, pt.x, 
                                                                         pt.y))
      f.close()
      self.metrics['numPoints'] = len(self.job.points)
      
# .............................................................................
class MEProjectionRunner(ApplicationRunner):
   """
   @summary: openModeller projection job runner
   """
   PROCESS_TYPE = 120
   # .......................................
   def _buildCommand(self):
      """
      @summary: Builds the command that will generate a projection
      @note: MaxEnt version 3.3.3e
      @note: Usage: java -cp maxent.jar density.Project lambdaFile gridDir outFile [args]

Here lambdaFile is a .lambdas file describing a Maxent model, and gridDir is a 
directory containing grids for all the predictor variables described in the 
.lambdas file.  As an alternative, gridDir could be an swd format file.  The 
optional args can contain any flags understood by Maxent -- for example, a 
"grd" flag would make the output grid of density.Project be in .grd format.
      """
      baseCmd = "{0}{1} {0}{2} {3}".format(self.env.getApplicationPath(), 
                                     self.env.config.get('maxent', 'JAVA_CMD'), 
                                     self.env.config.get('maxent', 'ME_CMD'), 
                                     self.env.config.get('maxent', 'PRJ_TOOL'))
      outFile = os.path.join(self.jobOutputDir, 'output.asc')
      args = "autorun -z"
      #cmd = "{baseCmd} {lambdaFile} {gridDir} {outFile} {args}".format(
      #            baseCmd=baseCmd, gridDir=gridDir, outFile=outFile, args=args)
      cmd = "{0} {1} {2} {3} {4}".format(baseCmd, self.lambdasFile, 
                                               self.jobLayerDir, outFile, args)
      return cmd
   
   # .......................................
   def _checkApplication(self):
      """
      @summary: Checks the openModeller output files to get the progress and 
                   status of the running projection.
      """
      pass
      
   # .......................................
   def _checkOutput(self):
      """
      @summary: Checks the output of openModeller to see if any errors occurred
      """
      pass
   
   # ...................................
   def _cleanUp(self):
      """
      @summary: Cleans up after a job has completed.  This should deleting all
                   files created by the job that do not need to be kept on the
                   node.
      """
      try:
         self.writeMetrics(self.PROCESS_TYPE, self.job.jobId)
      except:
         print "Failed to write metrics"
      
      try:
         self.log.debug("Job end time: %s" % self.endTime)
         import shutil
         if self.env.config.getboolean('options', 'Store Log Files'):
            shutil.move(self.jobLogFile, os.path.join(
                       self.env.config.get('options', 'Log Storage Location'), 
                       os.path.basename(self.jobLogFile)))
         shutil.rmtree(self.jobOutputDir)#, ignore_errors=True)
      except Exception, e:
         self.log.debug("Failed in cleanup: %s" % str(e))

   # .......................................
   def _initializeJob(self):
      """
      @summary: Initializes a projection for generation
      """
      self.metrics['jobId'] = self.job.jobId
      self.metrics['algorithm'] = 'MAXENT'
      self.metrics['processType'] = self.PROCESS_TYPE

      self.dataDir = self.env.getJobDataPath()
      self.jobOutputDir = os.path.join(self.env.getJobOutputPath(), 
                       "job-{0}-{1}".format(self.PROCESS_TYPE, self.job.jobId))
      self.jobLayerDir = os.path.join(self.jobOutputDir, 'layers')
      self.lambdasFile = os.path.join(self.jobOutputDir, 'input.lambdas')
      self.outputFile = os.path.join(self.jobOutputDir, 'output.asc')

      if not os.path.exists(self.jobLayerDir):
         os.makedirs(self.jobLayerDir)

      self.jobLogFile = "%s/jobLog-%s.log" % (self.jobOutputDir, self.job.jobId)
      
      self._initLogger('job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId), 
                                                               self.jobLogFile)

      # Logging
      self.log.debug("Job start time: %s" % self.startTime)
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Job Id: %s" % self.job.jobId)
      self.log.debug("User Id: %s" % self.job.userId)
      try:
         self.log.debug("Parent URL: %s" % self.job.parentUrl)
      except:
         pass
      try:
         self.log.debug("Object URL: %s" % self.job.url)
      except:
         pass
      self.log.debug("Institution: %s" % self.env.config.get('contact', 
                                                           'INSTITUTION_NAME'))
      self.log.debug("Admin: %s" % self.env.config.get('contact', 'ADMIN_NAME'))
      self.log.debug("Admin Email: %s" % self.env.config.get('contact', 
                                                                'ADMIN_EMAIL'))
      self.log.debug("Local Machine ID: %s" % self.env.config.get('contact', 
                                                           'LOCAL_MACHINE_ID'))
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Process Id: %s" % os.getpid())
      self.log.debug("-------------------------------------------------------")
      self.log.debug("MaxEnt Version: %s" % self.env.config.get('maxent', 
                                                                 'ME_VERSION'))
      self.log.debug("-------------------------------------------------------")
      self._logSystemInformation()

      handleLayers(self.job.layers, self.env, self.dataDir, self.jobLayerDir)
      
      f = open(self.lambdasFile, 'w')
      f.write(self.job.lambdas)
      f.close()
      
      # Determine directories
      # Write lambdas file
      # Statisitcs?
      # Output file
      

   # .......................................
   def _push(self):
      """
      @summary: Pushes the results of the job to the job server
      """
      component = "projection"
      contentType = "image/x-aaigrid"
      outFn = os.path.join(os.path.split(self.outputFile)[0], 'out.tif')
      convertLayerFormat(self.outputFile, outFn)
      #content = open(self.outputFile).read()
      content = open(outFn).read()
      self._update()

      try:
         self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, 
                                                        contentType, component)
         try:
            self._pushPackage()
         except:
            pass
      except Exception, e:
         try:
            self.log.debug(str(e))
         except: # Log not initialized
            pass
         self.status = JobStatus.PUSH_FAILED
         self._update()

   # ...................................
   def _pushPackage(self):
      """
      @summary: Pushes the entire package back to the job server
      @note: Does not push back layers directory
      """
      from StringIO import StringIO
      import zipfile

      component = "package"
      contentType = "application/zip"
      
      outStream = StringIO()
      zf = zipfile.ZipFile(outStream, 'w')
      
      zf.write(self.lambdasFile, os.path.split(self.lambdasFile)[1])
      zf.write(self.jobLogFile, os.path.split(self.jobLogFile)[1])

      zf.close()      
      outStream.seek(0)
      content = outStream.getvalue()      
      self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, contentType, 
                                                                     component)

# .................................
def getAlgorithmOptions(algo):
   """
   @summary: Processes the algorithm parameters provided to generate 
                command-line options
   """
   params = []
   if algo.parameter is not None:
      for param in algo.parameter:
         p = processParameter(param.id, param.value)
         if p is not None:
            params.append(p)
   return ' '.join(params)
         
# .................................
def processParameter(param, value):
   """
   @summary: Processes an individual parameter and value
   """
   p = PARAMETERS[param]
   v = p['process'](value)
   if p.has_key('options'):
      v = p['options'][v]
   if v != p['default']:
      return "--{parameter}={value}".format(parameter=param, value=v)
   else:
      return None

# .................................
def handleLayers(layerUrls, env, dataDir, jobLayerDir):
   """
   @summary: Iterates through the list of layer urls and stores them on the 
                file system if they are not there yet.  Then creates links
                in the job layer directory so that the layers may be stored
                long term on the machine but still used per job.
   @param layerUrls: List of layer urls
   @param env: The environment to operate in
   @param dataDir: Directory to store layers
   @param jobLayerDir: The layer directory of the job
   """
   lyrs = []
   lyrMgr = LayerManager(dataDir)
   for lyrUrl in layerUrls:
      lyrs.append(lyrMgr.getLayerFilename(lyrUrl))
   lyrMgr.close()
   for i in range(len(lyrs)):
      env.createLink("{0}/layer{1}.asc".format(jobLayerDir, i), lyrs[i])
      
"""
@summary: Module containing process runners to perform RAD randomizations
@author: CJ Grady
@version: 1.0
@status: alpha

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
import csv
import numpy
import os
from StringIO import StringIO
import urllib2
import zipfile

from LmCompute.common.lmXml import Element, SubElement, tostring
from LmCompute.jobRunners.base.pythonRunner import PythonRunner
from LmCompute.plugins.rad.common.constants import JobStatus
from LmCompute.plugins.rad.randomize.randomize import splotch, swap

# .............................................................................
class _RandomizeRunner(PythonRunner):
   """
   @summary: RAD randomize job runner base class
   """
   PROCESS_TYPE = None
   
   # ...................................
   def _initializeJob(self):
      self.outputPath = os.path.join(self.env.getJobOutputPath(), 
                             'job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId))
      
      if not os.path.exists(self.outputPath):
         os.makedirs(self.outputPath)

      self.jobLogFile = "%s/jobLog-%s.log" % (self.outputPath, self.job.jobId)
      self._initLogger('job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId), self.jobLogFile)
      self.log.debug("Job start time: %s" % self.startTime)
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Job Id: %s" % self.job.jobId)
      self.log.debug("User Id: %s" % self.job.userId)
      try:
         self.log.debug("Parent URL: %s" % self.job.parentUrl)
      except:
         pass
      try:
         self.log.debug("Object URL: %s" % self.job.url)
      except:
         pass
      self.log.debug("Institution: %s" % self.env.config.get('contact', 'INSTITUTION_NAME'))
      self.log.debug("Admin: %s" % self.env.config.get('contact', 'ADMIN_NAME'))
      self.log.debug("Admin Email: %s" % self.env.config.get('contact', 'ADMIN_EMAIL'))
      self.log.debug("Local Machine ID: %s" % self.env.config.get('contact', 'LOCAL_MACHINE_ID'))
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Process Id: %s" % os.getpid())
      self.log.debug("-------------------------------------------------------")
      self._logSystemInformation()
      
      self._processJobInput()
      
      self.status = JobStatus.COMPUTE_INITIALIZED
   
   # .......................................
   def _getMatrixFromCSV(self, matrixUrl):
      #print urllib2.urlopen(matrixUrl).read()
      csvContent = StringIO()
      csvContent.write(urllib2.urlopen(matrixUrl).read())
      csvContent.seek(0)
   
      sample = csvContent.read(1024)
      csvContent.seek(0)
      sniffer = csv.Sniffer()

      dialect = sniffer.sniff(sample)
      hasHeaders = sniffer.has_header(sample)
      
      csvReader = csv.reader(csvContent, dialect=dialect, lineterminator='\n')
   
      s = ';'.join([' '.join([c for c in r]) for r in csvReader][int(hasHeaders):])
      matrix = numpy.matrix(s)

      return matrix
   
   # .......................................
   def _push(self):
      """
      @summary: Pushes the results of the job to the job server
      """
      if self.status < JobStatus.GENERAL_ERROR:
         self.status = JobStatus.PUSH_REQUESTED
         component = "matrix"
         contentType = "application/octet-stream"
         
         self.outputMatrxFN = self.env.getTemporaryFilename('npy')
         print "Writing randomized matrix to:", self.outputMatrxFN 
         # Save to temporary file
         numpy.save(self.outputMatrxFN, self.randomMatrix)
         
         content = open(self.outputMatrxFN, 'rb').read()
         
         self._update()
         try:
            self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, 
                                contentType, component)
         except Exception, e:
            try:
               self.log.debug(str(e))
            except: # Log not initialized
               pass
            self.status = JobStatus.PUSH_FAILED
            self._update()
      else:
         component = "error"
         content = None

   # ...................................
   def _cleanUp(self):
      """
      @summary: Cleans up after a job has completed.  This should deleting all
                   files created by the job that do not need to be kept on the
                   node.
      """
      try: # Output some extra logging information
         self.log.debug("Job end time: %s" % self.endTime)
      except Exception, e:
         print str(e)
         #pass
      try:
         import shutil
         STORE_LOGS = self.env.config.getboolean('options', 'Store Log Files')
         LOG_LOCATION = self.env.config.get('options', 'Log Storage Location')
         if STORE_LOGS:
            shutil.move(self.jobLogFile, os.path.join(LOG_LOCATION, os.path.basename(self.jobLogFile)))
         shutil.rmtree(self.outputPath)#, ignore_errors=True)
      except:
         pass
   
   # ...................................
   def _storeVectorFile(self, sgUrl):
      self.log.debug("Trying to retrieve: %s" % sgUrl)
      fn = None
      outDir = os.path.join(self.outputPath, 'vectorLayers')
      if not os.path.exists(outDir):
         os.mkdir(outDir)
      
      # Get the zip file
      content = ''.join(urllib2.urlopen(sgUrl).readlines())
      content = StringIO(content)
      content.seek(0)
      # Extract it
      with zipfile.ZipFile(content) as z:
         for name in z.namelist():
            if name.endswith('shp'):
               fn = os.path.join(outDir, name)
            z.extract(name, outDir)

      self.log.debug("Returning: %s" % fn)
      return fn
   

# .............................................................................
class RandomizeSplotchRunner(_RandomizeRunner):
   """
   @summary: RAD randomize splotch job runner
   """
   PROCESS_TYPE = 332
   
   # ...................................
   def _doWork(self):
      self.status, self.randomMatrix = splotch(self.matrix, self.shapegrid, 
                                            self.siteCount, self.layersPresent, self.env)
   
   # ...................................
   def _processJobInput(self):
      self.log.debug("Start of process job input")
      sgUrl = self.job.shapegrid.url
      print self.job.matrix.url
       
      self.shapegrid = {
                   'dlocation' : self._storeVectorFile(sgUrl),
                   'localIdIdx' : self.job.shapegrid.localIdIndex,
                   'cellsideCount' : self.job.shapegrid.cellsides
                  }
      
      self.matrix = self._getMatrixFromCSV(self.job.matrix.url)
      
      # Needs to be a dictionary
      self.layersPresent = {}
      for lyr in self.job.layersPresent.layer:
         # Only need the keys for splotch
         self.layersPresent[lyr.key] = True
   
      self.siteCount = len(self.job.sitesPresent.site)
   
# .............................................................................
class RandomizeSwapRunner(_RandomizeRunner):
   """
   @summary: RAD randomize swap job runner
   """
   PROCESS_TYPE = 331
   
   # ...................................
   def _doWork(self):

      self.status, self.randomMatrix, self.counter = swap(self.matrix, 
                                                           self.sitesPresent, 
                                                           self.layersPresent, 
                                                           self.iterations)
   # ...................................
   def _processJobInput(self):
      self.log.debug("Start of process job input")
#       sgUrl = self.job.shapegrid.url
#        
#       self.shapegrid = {
#                    'dlocation' : self._storeVectorFile(sgUrl),
#                    'localIdIdx' : self.job.shapegrid.localIdIndex,
#                    'cellsideCount' : self.job.shapegrid.cellsides
#                   }
      
      self.matrix = self._getMatrixFromCSV(self.job.matrix.url)

      # Needs to be a dictionary
      self.layersPresent = {}
      for lyr in self.job.layersPresent.layer:
         l = {}
         for k in lyr._attribs.keys():
            if k != "key":
               l[k] = lyr._attribs[k]
         self.layersPresent[lyr.key] = l
   
      # Needs to be a dictionary
      self.sitesPresent = {}
      for site in self.job.sitesPresent.site:
         s = {}
         for k in site._attribs.keys():
            if k != "key":
               s[k] = site._attribs[k]
         self.sitesPresent[site.key] = s
      
      self.iterations = int(self.job.iterations)
   

"""
@summary: Module containing GBIF process runners
@author: CJ Grady
@version: 1.0
@status: alpha

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
import glob
import os
from StringIO import StringIO
from time import sleep
import zipfile

from LmCompute.common.lmConstants import SHAPEFILE_EXTENSIONS
from LmCompute.jobRunners.base.pythonRunner import PythonRunner
from LmCompute.plugins.sdm.gbif.constants import JobStatus
from LmCompute.plugins.sdm.gbif.gbif import isGBIFDownloadReady, \
                                                 retrieveGBIFData

SLEEP_TIME = 600 # Ten minutes

# .............................................................................
class GBIFRetrieverRunner(PythonRunner):
   """
   @summary: Process runner to retrieve occurrence data from GBIF from a 
                download key
   """
   PROCESS_TYPE = 405

   # ...................................
   def _initializeJob(self):
      self.outputPath = os.path.join(self.env.getJobOutputPath(), 
                             'job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId))
      if not os.path.exists(self.outputPath):
         os.makedirs(self.outputPath)

      self.jobLogFile = "%s/jobLog-%s.log" % (self.outputPath, self.job.jobId)
      self._initLogger('job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId), 
                                                               self.jobLogFile)
      self.log.debug("Job start time: %s" % self.startTime)
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Job Id: %s" % self.job.jobId)
      self.log.debug("User Id: %s" % self.job.userId)
      try:
         self.log.debug("Parent URL: %s" % self.job.parentUrl)
      except:
         pass
      try:
         self.log.debug("Object URL: %s" % self.job.url)
      except:
         pass
      self.log.debug("Institution: %s" % self.env.config.get('contact', 
                                                           'INSTITUTION_NAME'))
      self.log.debug("Admin: %s" % self.env.config.get('contact', 
                                                                 'ADMIN_NAME'))
      self.log.debug("Admin Email: %s" % self.env.config.get('contact', 
                                                                'ADMIN_EMAIL'))
      self.log.debug("Local Machine ID: %s" % self.env.config.get('contact', 
                                                           'LOCAL_MACHINE_ID'))
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Process Id: %s" % os.getpid())
      self.log.debug("-------------------------------------------------------")
      self._logSystemInformation()
      
      # Get the job inputs
      self.gbifDownloadKey = self.job.gbifKey
      #self.downloadUrl = self.job.downloadUrl
      
      self.status = JobStatus.COMPUTE_INITIALIZED
   
   # ...................................
   def _doWork(self):
      while not self._poll():
         self._wait()
      # Retrieve points
      self.shapefileLocation = retrieveGBIFData(self.downloadUrl, 
                        self.outputPath, appPath=self.env.getApplicationPath())
      
   # ...................................
   def _getFiles(self, shapefileName):
      return glob.iglob('%s*' % os.path.splitext(shapefileName)[0])

   # ...................................
   def _poll(self):
      self.downloadUrl = isGBIFDownloadReady(self.gbifDownloadKey)
      return self.downloadUrl
   
   # ...................................
   def _wait(self):
      sleep(SLEEP_TIME)
      
   # .......................................
   def _push(self):
      """
      @summary: Pushes the results of the job to the job server
      """
      component = "shapefile"
      contentType = "application/zip"
      # Read shapefile into StringIO object
      outStream = StringIO()
      with zipfile.ZipFile(outStream, 'w') as zf:
         # Determine all files to include
         for f in self._getFiles(self.shapefileLocation):
            if os.path.splitext(f)[1] in SHAPEFILE_EXTENSIONS:
               zf.write(f, os.path.basename(f))
      # Post shapefile
      outStream.seek(0)
      content = outStream.getvalue()
      self._update()
      try:
         self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, 
                          contentType, component)
      except Exception, e:
         try:
            self.log.debug(str(e))
         except:
            pass
         self.status = JobStatus.PUSH_FAILED
         self._update()


   # ...................................
   def _cleanUp(self):
      """
      @summary: Cleans up after a job has completed.  This should deleting all
                   files created by the job that do not need to be kept on the
                   node.
      """
      try: # Output some extra logging information
         self.log.debug("Job end time: %s" % self.endTime)
      except Exception, e:
         print str(e)
         #pass
      try:
         import shutil
         STORE_LOGS = self.env.config.getboolean('options', 'Store Log Files')
         LOG_LOCATION = self.env.config.get('options', 'Log Storage Location')
         if STORE_LOGS:
            shutil.move(self.jobLogFile, os.path.join(LOG_LOCATION, 
                                            os.path.basename(self.jobLogFile)))
         if self.status == JobStatus.COMPLETE:
            shutil.rmtree(self.outputPath)#, ignore_errors=True)
      except:
         pass
   
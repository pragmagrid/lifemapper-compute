"""
@summary: Module containing constants for GBIF runner processes
@author: CJ Grady
@version: 1.0
@status: alpha

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
from LmCompute.common.lmConstants import JobStatus as parentJobStatus
from osgeo import ogr

class JobStatus(parentJobStatus):
   pass

# GBIF Login
USER = 'aimee'

# For writing zip file, then shapefile
SHAPEFILE_MAX_STRINGSIZE = 255

# For web url to individual points
GBIF_OCCURRENCE_URL = 'http://www.gbif.org/occurrence/'

# For querying GBIF REST service for data
GBIF_REST_URL = 'http://api.gbif.org/v0.9'
GBIF_OCCURRENCE_SERVICE = 'occurrence'
GBIF_DOWNLOAD_COMMAND = 'download'

GBIF_RESPONSE_STATUS_KEY = 'status'
GBIF_RESPONSE_LINK_KEY = 'downloadLink'
GBIF_RESPONSE_SIZE_KEY = 'size'
GBIF_RESPONSE_COUNT_KEY = 'totalRecords'
GBIF_RESPONSE_STATUS_COMPLETE_VALUE = 'SUCCEEDED'

# GBIF Output files of interest
GBIF_FIELD_METADATA_FILENAME = 'meta.xml'
GBIF_OCCURRENCE_FILENAME = 'occurrence.txt'
DWC_NAMESPACE = '{http://rs.tdwg.org/dwc/text/}'
DWC_PREFIX = 'http://rs.tdwg.org/dwc/terms/'
DWC_X_FIELD = 'decimalLongitude'
DWC_Y_FIELD = 'decimalLatitude'
DWC_ID_FIELD = 'occurrenceID'

DWC_TRANSLATIONS = {'occurrenceID': ('occkey', ogr.OFTInteger), 
                    'datasetID': ('dataid', ogr.OFTString),
                    'institutionCode': ('instcode', ogr.OFTString),
                    'collectionCode': ('collcode', ogr.OFTString),
                    'catalogNumber': ('catnum', ogr.OFTString),
                    'basisOfRecord': ('basis', ogr.OFTString),
                    'scientificName': ('sciname', ogr.OFTString),
                    'scientificNameAuthorship': ('sciauth', ogr.OFTString),
                    'taxonID': ('taxonid', ogr.OFTInteger),
                    'kingdom': ('kingdom', ogr.OFTString),
                    'phylum': ('phylum', ogr.OFTString),
                    'class': ('class', ogr.OFTString),
                    'order': ('order', ogr.OFTString),
                    'family': ('family', ogr.OFTString), 
                    'genus': ('genus', ogr.OFTString),
                    'specificEpithet': ('specepi', ogr.OFTString),
                    'countryCode': ('ctrycode', ogr.OFTString),
                    'decimalLatitude': ('dec_lat', ogr.OFTReal),
                    'decimalLongitude': ('dec_long', ogr.OFTReal),
                    'year': ('year', ogr.OFTInteger),
                    'month': ('month', ogr.OFTInteger),
                    'eventDate': ('evtdate', ogr.OFTString),
                    'taxonRank': ('rank', ogr.OFTString),
                    'verbatimLatitude': ('ver_lat', ogr.OFTString),
                    'verbatimLongitude': ('ver_long', ogr.OFTString),
                    'coordinatePrecision': ('prec', ogr.OFTReal),
                    'maximumElevationInMeters': ('maxelev', ogr.OFTReal),
                    'minimumElevationInMeters': ('minelev', ogr.OFTReal),
                    'minimumDepthInMeters': ('maxdepth', ogr.OFTReal),
                    'maximumDepthInMeters': ('mindepth', ogr.OFTReal),
                    'continent': ('cont', ogr.OFTString),
                    'stateProvince': ('stprov', ogr.OFTString),
                    'county': ('county', ogr.OFTString),
                    'country': ('country', ogr.OFTString),
                    'recordedBy': ('rec_by', ogr.OFTString),
                    'locality': ('locality', ogr.OFTString),
                    'day': ('day', ogr.OFTString),
                    'identifiedBy': ('id_by', ogr.OFTString),
                    'dateIdentified': ('dateid', ogr.OFTString)}
# We are adding these 2 fields
LM_WKT_FIELD = 'geomwkt'
GBIF_LINK_FIELD = 'gbifurl'
LM_ADD_FIELDS = {LM_WKT_FIELD: ogr.OFTString, GBIF_LINK_FIELD: ogr.OFTString}

 
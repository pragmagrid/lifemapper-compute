"""
@summary: Module containing the job runners for openModeller models and 
             projections
@author: CJ Grady
@version: 3.0
@status: alpha

@note: Commands are for openModeller library version 1.3.0
@note: Commands may be backwards compatible

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
import os
from subprocess import Popen, PIPE

from LmCompute.jobRunners.base.applicationRunner import ApplicationRunner
from LmCompute.plugins.sdm.openModeller.constants import JobStatus
from LmCompute.plugins.sdm.openModeller.omRequest import OmModelRequest, \
                                                            OmProjectionRequest

# .............................................................................
class OMModelRunner(ApplicationRunner):
   """
   @summary: openModeller model job runner
   """
   PROCESS_TYPE = 210
   # ...................................
   def _buildCommand(self):
      """
      @summary: Builds the command that will generate a model
      @return: A bash command to run
      
      @note: om_model version 1.3.0
      @note: Usage - om_model [options [args]]
         --help,       -h          Displays this information
         --version,    -v          Display version info
         --xml-req,    -r <args>   Model creation request file in XML
         --model-file, -m <args>   File to store the generated model
         --log-level <args>        Set the log level (debug, warn, info, error)
         --log-file <args>         Log file
         --prog-file <args>        File to store model creation progress
      """
      cmd = "%s%s -r %s -m %s --log-level %s --log-file %s --prog-file %s" % \
               (self.env.getApplicationPath(), self.env.config.get(
                                               'openModeller', 'OM_MODEL_CMD'), 
                self.modelRequestFile, self.modelResultFile,
                self.modelLogLevel, self.modelLogFile, self.modelProgressFile)
      return cmd
   
   # ...................................
   def _checkApplication(self):
      """
      @summary: Checks the openModeller output files to get the progress and 
                   status of the running model.
      """
      f = open(self.modelProgressFile)
      self.progress = int(''.join(f.readlines()))
      f.close()
   
   # ...................................
   def _checkOutput(self):
      """
      @summary: Checks the output of openModeller to see if any errors occurred
      """
      if self.progress == -2:
         self.status = self._getModelErrorStatus()
      elif self.progress == 100:
         self.status = JobStatus.COMPUTED
      else:
         # Probably a seg fault or killed by signal
         self.status = self._getModelErrorStatus()
         
   # ...................................
   def _cleanUp(self):
      """
      @summary: Cleans up after a job has completed.  This should deleting all
                   files created by the job that do not need to be kept on the
                   node.
      """
      try:
         self.writeMetrics(self.PROCESS_TYPE, self.job.jobId)
      except Exception, e:
         print "Failed to write metrics"
         print str(e)
      
      try: # Output some extra logging information
         f = open(self.modelResultFile)
         res = f.read()
         f.close()
         self.log.debug("Job end time: %s" % self.endTime)
         print "\n\n-------------\nModel Results\n-------------\n\n"
         print res
      except Exception, e:
         print str(e)
         #pass
      try:
         import shutil
         STORE_LOGS = self.env.config.getboolean('options', 'Store Log Files')
         LOG_LOCATION = self.env.config.get('options', 'Log Storage Location')
         if STORE_LOGS:
            shutil.move(self.modelLogFile, os.path.join(LOG_LOCATION, 
                                          os.path.basename(self.modelLogFile)))
            shutil.move(self.jobLogFile, os.path.join(LOG_LOCATION, 
                                            os.path.basename(self.jobLogFile)))
         shutil.rmtree(self.outputPath)#, ignore_errors=True)
      except:
         pass
   
   # ...................................
   def _initializeJob(self):
      """
      @summary: Initializes a model to be ran by openModeller
      """
      self.metrics['jobId'] = self.job.jobId
      self.metrics['processType'] = self.PROCESS_TYPE
      self.metrics['algorithm'] = self.job.algorithm.code

      self.outputPath = os.path.join(self.env.getJobOutputPath(), 
                                     'job-%s-%s' % (self.PROCESS_TYPE, 
                                                    self.job.jobId))
      
      if not os.path.exists(self.outputPath):
         os.makedirs(self.outputPath)

      self.modelLogFile = "%s/modLog-%s.log" % (self.outputPath, self.job.jobId)
      self.modelProgressFile = "%s/modProg-%s.txt" % (self.outputPath, 
                                                      self.job.jobId)
      self.modelRequestFile = "%s/modReq-%s.xml" % (self.outputPath, 
                                                    self.job.jobId)
      self.modelResultFile = "%s/mod-%s.xml" % (self.outputPath, self.job.jobId)
      self.jobLogFile = "%s/jobLog-%s.log" % (self.outputPath, self.job.jobId)
      
      self._initLogger('job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId), 
                                                               self.jobLogFile)
      self.log.debug("Job start time: %s" % self.startTime)
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Job Id: %s" % self.job.jobId)
      self.log.debug("User Id: %s" % self.job.userId)
      try:
         self.log.debug("Parent URL: %s" % self.job.parentUrl)
      except:
         pass
      try:
         self.log.debug("Object URL: %s" % self.job.url)
      except:
         pass
      self.log.debug("Institution: %s" % self.env.config.get('contact', 
                                                           'INSTITUTION_NAME'))
      self.log.debug("Admin: %s" % self.env.config.get('contact', 
                                                                 'ADMIN_NAME'))
      self.log.debug("Admin Email: %s" % self.env.config.get('contact', 
                                                                'ADMIN_EMAIL'))
      self.log.debug("Local Machine ID: %s" % self.env.config.get('contact', 
                                                           'LOCAL_MACHINE_ID'))
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Process Id: %s" % os.getpid())
      self.log.debug("-------------------------------------------------------")
      self.log.debug("openModeller Version: %s" % self.env.config.get(
                                                 'openModeller', 'OM_VERSION'))
      self.log.debug("-------------------------------------------------------")
      self._logSystemInformation()

      self.modelLogLevel = self.env.config.get('openModeller', 
                                                           'DEFAULT_LOG_LEVEL')
      
      # Generate a model request file and write it to the file system
      req = OmModelRequest(self.job, self.env.getJobDataPath())
      reqFile = open(self.modelRequestFile, "w")
      cnt = req.generate()
     
      # At least as of openModeller 1.3, need to remove the xml version line
      if cnt.startswith("<?xml version"):
         tmp = cnt.split('\n')
         cnt = '\n'.join(tmp[1:])
      reqFile.write(cnt)
      reqFile.close()
      self.status = JobStatus.COMPUTE_INITIALIZED
   
   # .......................................
   def _getModelErrorStatus(self):
      """
      @summary: Checks the model log file to determine what error occurred. 
      """
      f = open(self.modelLogFile)
      omLog = ''.join(f.readlines())
      f.close()
      
      status = JobStatus.UNKNOWN_ERROR
      
      if omLog.find("[Error] No presence points available") >= 0:
         status = JobStatus.OM_MOD_REQ_POINTS_MISSING_ERROR
      elif omLog.find(
          "[Error] Cannot use zero presence points for sampling") >= 0:
         status = JobStatus.OM_MOD_REQ_POINTS_MISSING_ERROR
      elif omLog.find(
          "[Error] Cannot create model without any presence or absence point."
          ) >= 0:
         status = JobStatus.OM_MOD_REQ_POINTS_OUT_OF_RANGE_ERROR
      elif omLog.find("[Error] XML Parser fatal error: not well-formed") >= 0:
         status = JobStatus.OM_MOD_REQ_ERROR
      elif omLog.find("[Error] Unable to open file") >= 0:
         status = JobStatus.OM_MOD_REQ_LAYER_ERROR
      elif omLog.find("[Error] Algorithm %s not found" % \
                                            self.job.algoCode) >= 0:
         status = JobStatus.OM_MOD_REQ_ALGO_INVALID_ERROR
      elif omLog.find("[Error] Parameter") >= 0:
         if omLog.find("not set properly.\n", 
                                         omLog.find("[Error] Parameter")) >= 0:
            status = JobStatus.OM_MOD_REQ_ALGOPARAM_MISSING_ERROR
      return status
   
   # .......................................
   def _push(self):
      """
      @summary: Pushes the results of the job to the job server
      """
      if self.status < JobStatus.GENERAL_ERROR:
         self.status = JobStatus.PUSH_REQUESTED
         component = "model"
         contentType = "application/xml"
         content = open(self.modelResultFile).read()
         self.log.debug("\n\n-------------\nModel Results\n-------------\n\n")
         self.log.debug(content)
         self._update()
         try:
            self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, 
                                                        contentType, component)
            try:
               self._pushPackage()
            except:
               pass
         except Exception, e:
            try:
               self.log.debug(str(e))
            except: # Log not initialized
               pass
            self.status = JobStatus.PUSH_FAILED
            self._update()
      else:
         component = "error"
         content = None

   # ...................................
   def _pushPackage(self):
      """
      @summary: Pushes the entire package back to the job server
      @note: Does not push back layers directory
      """
      from StringIO import StringIO
      import zipfile

      component = "package"
      contentType = "application/zip"
      
      outStream = StringIO()
      zf = zipfile.ZipFile(outStream, 'w')
      zf.write(self.modelLogFile, os.path.split(self.modelLogFile)[1])
      zf.write(self.modelResultFile, os.path.split(self.modelResultFile)[1])
      zf.write(self.modelRequestFile, os.path.split(self.modelRequestFile)[1])
      zf.write(self.jobLogFile, os.path.split(self.jobLogFile)[1])
      zf.close()      
      outStream.seek(0)
      content = outStream.getvalue()      
      self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, contentType, 
                                                                     component)
   
# .............................................................................
class OMProjectionRunner(ApplicationRunner):
   """
   @summary: openModeller projection job runner
   """
   PROCESS_TYPE = 220
   # .......................................
   def _buildCommand(self):
      """
      @summary: Builds the command that will generate a projection
      @note: om_project version 1.3.0
      @note: Usage: om_project [options [args]]
        --help,      -h          Displays this information
        --version,   -v          Display version info
        --xml-req,   -r <args>   Projection request file in XML
        --model,     -o <args>   File with serialized model (native projection)
        --template,  -t <args>   Raster template for the distribution map 
                                    (native projection)
        --format,    -f <args>   File format for the distribution map 
                                    (native projection)
        --dist-map,  -m <args>   File to store the generated model
        --log-level <args>       Set the log level (debug, warn, info, error)
        --log-file <args>        Log file
        --prog-file <args>       File to store projection progress
        --stat-file <args>       File to store projection statistics
      """
      cmd = "%s%s -r %s -m %s --log-level %s --log-file %s --prog-file %s --stat-file %s" % \
            (self.env.getApplicationPath(), self.env.config.get('openModeller', 
                                                             'OM_PROJECT_CMD'), 
             self.projRequestFile, self.projResultFile,
             self.projLogLevel, self.projLogFile, self.projProgressFile,
             self.projStatFile)
      return cmd
   
   # .......................................
   def _checkApplication(self):
      """
      @summary: Checks the openModeller output files to get the progress and 
                   status of the running projection.
      """
      f = open(self.projProgressFile)
      self.progress = int(''.join(f.readlines()))
      f.close()
      
   # .......................................
   def _checkOutput(self):
      """
      @summary: Checks the output of openModeller to see if any errors occurred
      """
      if self.progress == -2:
         self.status = self._getProjectionErrorStatus()
      elif self.progress == 100:
         self.status = JobStatus.COMPUTED
      else:
         # Probably a seg fault or killed by signal
         self.status = self._getProjectionErrorStatus()
   
   # .......................................
   def _getProjectionErrorStatus(self):
      """
      @summary: Checks the projection log file to determine what error occurred
      @todo: Look for errors in log file
      """
      #f = open(self.projLogFile)
      #omLog = ''.join(f.readlines())
      #f.close()
      
      # Need to look for specific projection errors
      status = JobStatus.OM_PROJECTION_ERROR
      
      return status
   
   # .......................................
   def _initializeJob(self):
      """
      @summary: Initializes a projection for generation
      """
      self.metrics['jobId'] = self.job.jobId
      self.metrics['processType'] = self.PROCESS_TYPE

      self.outputPath = os.path.join(self.env.getJobOutputPath(), 
                             'job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId))
      
      if not os.path.exists(self.outputPath):
         os.makedirs(self.outputPath)

      self.projLogFile = "%s/projLog-%s.log" % (self.outputPath, self.job.jobId)
      self.projLogLevel = self.env.config.get('openModeller', 
                                                           'DEFAULT_LOG_LEVEL')
      self.projProgressFile = "%s/projProg-%s.txt" % (self.outputPath, 
                                                                self.job.jobId)
      self.projRequestFile = "%s/projReq-%s.xml" % (self.outputPath, 
                                                                self.job.jobId)
      self.projResultFile = "%s/proj-%s.tif" % (self.outputPath, self.job.jobId)
      self.projStatFile = "%s/projStats-%s.txt" % (self.outputPath, 
                                                                self.job.jobId)
      
      self.jobLogFile = "%s/jobLog-%s.log" % (self.outputPath, self.job.jobId)
      
      self._initLogger('job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId), 
                                                               self.jobLogFile)
      self.log.debug("Job start time: %s" % self.startTime)
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Job Id: %s" % self.job.jobId)
      self.log.debug("User Id: %s" % self.job.userId)
      try:
         self.log.debug("Parent URL: %s" % self.job.parentUrl)
      except:
         pass
      try:
         self.log.debug("Object URL: %s" % self.job.url)
      except:
         pass
      self.log.debug("Institution: %s" % self.env.config.get('contact', 
                                                           'INSTITUTION_NAME'))
      self.log.debug("Admin: %s" % self.env.config.get('contact', 'ADMIN_NAME'))
      self.log.debug("Admin Email: %s" % self.env.config.get('contact', 
                                                                'ADMIN_EMAIL'))
      self.log.debug("Local Machine ID: %s" % self.env.config.get('contact', 
                                                           'LOCAL_MACHINE_ID'))
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Process Id: %s" % os.getpid())
      self.log.debug("-------------------------------------------------------")
      self._logSystemInformation()

      # Generate a projection request file and write it to the file system
      req = OmProjectionRequest(self.job, self.env.getJobDataPath())
      reqFile = open(self.projRequestFile, "w")
      cnt = req.generate()
     
      # At least as of openModeller 1.3, need to remove the xml version line
      if cnt.startswith("<?xml version"):
         tmp = cnt.split('\n')
         cnt = '\n'.join(tmp[1:])
      reqFile.write(cnt)
      reqFile.close()
      self.status = JobStatus.COMPUTE_INITIALIZED

   # ...................................
   def _cleanUp(self):
      """
      @summary: Cleans up after a job has completed.  This should deleting all
                   files created by the job that do not need to be kept on the
                   node.
      """
      try:
         self.writeMetrics(self.PROCESS_TYPE, self.job.jobId)
      except Exception, e:
         print "Failed to write metrics"
         print str(e)
      
      try: # Output some extra logging information
         print "\n\n-----------------\nProjection Stats\n-----------------\n\n"
         self.log.debug("\n\n------------\nProjection Stats\n------------\n\n")
         f = open(self.projStatFile)
         res = f.read()
         print res
         self.log.debug(res)
         f.close()
         print "\n\n----------------\nGDAL Info\n----------------\n\n"
         self.log.debug("\n\n---------------\nGDAL Info\n---------------\n\n")
         cmd = "%s -mm -stats %s" % (self.env.config.get('commands', 
                                          'GDALINFO_CMD'), self.projResultFile)
         p = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
         so, se = p.communicate()
         print so
         self.log.debug(so)
         print
         print se
         self.log.debug(se)
         self.log.debug("Job end time: %s" % self.endTime)
      except Exception, e:
         print str(e)
         self.log.debug(str(e))
      try:
         import shutil
         STORE_LOGS = self.env.config.getboolean('options', 'Store Log Files')
         LOG_LOCATION = self.env.config.get('options', 'Log Storage Location')
         if STORE_LOGS:
            shutil.move(self.projLogFile, os.path.join(LOG_LOCATION, 
                                           os.path.basename(self.projLogFile)))
            shutil.move(self.projStatFile, os.path.join(LOG_LOCATION, 
                                          os.path.basename(self.projStatFile)))
            shutil.move(self.jobLogFile, os.path.join(LOG_LOCATION, 
                                            os.path.basename(self.jobLogFile)))
         shutil.rmtree(self.outputPath)#, ignore_errors=True)
      except:
         pass

   # .......................................
   def _push(self):
      """
      @summary: Pushes the results of the job to the job server
      """
      if self.status < JobStatus.GENERAL_ERROR:
         self.status = JobStatus.PUSH_REQUESTED
         component = "projection"
         contentType = "image/tiff"
         content = open(self.projResultFile).read()
         self._update()
         try:
            self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, 
                                                        contentType, component)
            try:
               self._pushPackage()
            except:
               pass
         except Exception, e:
            try:
               self.log.debug(str(e))
            except: # Log not initialized
               pass
            self.status = JobStatus.PUSH_FAILED
            self._update()
      else:
         component = "error"
         content = None

   # ...................................
   def _pushPackage(self):
      """
      @summary: Pushes the entire package back to the job server
      @note: Does not push back layers directory
      """
      from StringIO import StringIO
      import zipfile

      component = "package"
      contentType = "application/zip"
      
      outStream = StringIO()
      zf = zipfile.ZipFile(outStream, 'w')
      
      zf.write(self.projLogFile, os.path.split(self.projLogFile)[1])
      zf.write(self.projRequestFile, os.path.split(self.projRequestFile)[1])
      zf.write(self.projStatFile, os.path.split(self.projStatFile)[1])
      zf.write(self.jobLogFile, os.path.split(self.jobLogFile)[1])

      zf.close()      
      outStream.seek(0)
      content = outStream.getvalue()      
      self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, contentType, 
                                                                     component)

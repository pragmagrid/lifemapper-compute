"""
@summary: Tests the Lifemapper RAD intesect configuration
@author: CJ Grady
@version: 1.0
@status: alpha

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
import os
# from common.config import Config
# from environment.localEnv import LocalEnv
# from plugins.omSdm.processRunner import OMModelRunner, OMProjectionRunner
from LmCompute.common.controller import JobController
from LmCompute.environment.localEnv import LocalEnv
from LmCompute.environment.testEnv import TestEnv

# .............................................................................
def testInputDirectory(env):
   """
   @summary: Tests that the job input directories can be written to
   @param env: An environment class to test
   """
   print "testInputDirectory"
   oDir = env.getJobDataPath()
   fn = "%s%s" % (oDir, 'write_test.txt')
   f = open(fn, 'w')
   f.write('test')
   f.close()
   os.remove(fn)

# .............................................................................
def testOutputDirectory(env):
   """
   @summary: Tests that the job output directories can be written to
   @param env: An environment class to test
   """
   print "testOutputDirectory"
   oDir = env.getJobOutputPath()
   fn = "%s/%s" % (oDir, 'write_test.txt')
   f = open(fn, 'w')
   f.write('test')
   f.close()
   os.remove(fn)

# .............................................................................
def testRunSampleIntersect():
   """
   @summary: Attempts to run a sample intersect job
   """
   print "testRunSampleIntersect"
   env = TestEnv()
   jc = JobController(env)
   jts = [310]
   for jt in jts:
      jc.run(jobTypes=[jt])

# .............................................................................
def testRunIntersect(env):
   print "testRunIntersect"
   jc = JobController(env)
   jts = [310]
   for jt in jts:
      jc.run(jobTypes=[jt])


# -----------------------------------------------------------------------------
def runTests(env=None):
   """
   @summary: Runs the tests associated with the Lifemapper openModeller plugin
   @param env: (optional) The environment to test in
   """
   if env is None:
      env = LocalEnv()
   testInputDirectory(env)
   testOutputDirectory(env)
   #testRunSampleIntersect()
   testRunIntersect(LocalEnv())

# ============================================================================
if __name__ == '__main__':
   runTests()

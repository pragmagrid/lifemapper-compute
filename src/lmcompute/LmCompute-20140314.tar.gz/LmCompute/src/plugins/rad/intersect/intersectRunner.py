"""
@summary: Module containing the job runner for the RAD intersect process
@author: CJ Grady
@version: 3.0
@status: alpha

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.

@todo: Store vector files using layer manager
"""
import os
from StringIO import StringIO
import urllib2
import zipfile

from LmCompute.common.layerManager import LayerManager
from LmCompute.common.lmXml import Element, SubElement, tostring
from LmCompute.jobRunners.base.pythonRunner import PythonRunner
from LmCompute.plugins.rad.common.constants import JobStatus
from LmCompute.plugins.rad.intersect.radIntersect import intersect

# .............................................................................
class IntersectRunner(PythonRunner):
   """
   @summary: RAD intersect job runner
   """
   PROCESS_TYPE = 310
   
   # ...................................
   def _initializeJob(self):
      self.outputPath = os.path.join(self.env.getJobOutputPath(), 
                             'job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId))
      
      if not os.path.exists(self.outputPath):
         os.makedirs(self.outputPath)

      self.jobLogFile = "%s/jobLog-%s.log" % (self.outputPath, self.job.jobId)
      self._initLogger('job-%s-%s' % (self.PROCESS_TYPE, self.job.jobId), 
                                                               self.jobLogFile)
      self.log.debug("Job start time: %s" % self.startTime)
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Job Id: %s" % self.job.jobId)
      self.log.debug("User Id: %s" % self.job.userId)
      try:
         self.log.debug("Parent URL: %s" % self.job.parentUrl)
      except:
         pass
      try:
         self.log.debug("Object URL: %s" % self.job.url)
      except:
         pass
      self.log.debug("Institution: %s" % self.env.config.get('contact', 
                                                           'INSTITUTION_NAME'))
      self.log.debug("Admin: %s" % self.env.config.get('contact', 'ADMIN_NAME'))
      self.log.debug("Admin Email: %s" % self.env.config.get('contact', 
                                                                'ADMIN_EMAIL'))
      self.log.debug("Local Machine ID: %s" % self.env.config.get('contact', 
                                                           'LOCAL_MACHINE_ID'))
      self.log.debug("-------------------------------------------------------")
      self.log.debug("Process Id: %s" % os.getpid())
      self.log.debug("-------------------------------------------------------")
      self._logSystemInformation()
      
      self.layers, self.shapegrid = self._processJobInput()
      
      self.status = JobStatus.COMPUTE_INITIALIZED
   
   # ...................................
   def _storeVectorFile(self, sgUrl):
      self.log.debug("Trying to retrieve: %s" % sgUrl)
      fn = None
      outDir = os.path.join(self.outputPath, 'vectorLayers')
      if not os.path.exists(outDir):
         os.mkdir(outDir)
      
      # Get the zip file
      content = ''.join(urllib2.urlopen(sgUrl).readlines())
      content = StringIO(content)
      content.seek(0)
      # Extract it
      with zipfile.ZipFile(content) as z:
         for name in z.namelist():
            if name.endswith('shp'):
               fn = os.path.join(outDir, name)
            z.extract(name, outDir)

      self.log.debug("Returning: %s" % fn)
      return fn
   
   # ...................................
   def _processJobInput(self):
      self.log.debug("Start of process job input")
      lyrMgr = LayerManager(self.env.getJobDataPath())
      
      self.log.debug("Layer manager has been initialized")
      sgUrl = self.job.shapegrid.url
      
      shapegrid = {
                   'dlocation' : self._storeVectorFile(sgUrl),
                   #'dlocation' : lyrMgr.getLayerFilename(sgUrl),
                   'localIdIdx' : self.job.shapegrid.localIdIndex
                  }
      
      layers = {}
      self.log.debug("Processing layers")
      for lyr in self.job.layerSet.layer:
         self.log.debug(" -- Processing layer %s" % lyr.index)
         lyrVals = {
                   }
         if lyr.isRaster.lower() != "false":
            lyrVals['isRaster'] = True
            lyrVals['resolution'] = lyr.resolution
            lyrVals['dlocation'] = lyrMgr.getLayerFilename(lyr.url)
         else:
            lyrVals['isRaster'] = False
            lyrVals['dlocation'] = self._storeVectorFile(lyr.url)

         try:
            lyrVals['isOrganism'] = True
            lyrVals['attrPresence'] = lyr.attrPresence
            lyrVals['minPresence'] = lyr.minPresence
            lyrVals['maxPresence'] = lyr.maxPresence
            lyrVals['percentPresence'] = lyr.percentPresence
            lyrVals['attrAbsence'] = lyr.attrAbsence
            lyrVals['minAbsence'] = lyr.minAbsence
            lyrVals['maxAbsence'] = lyr.maxAbsence
            lyrVals['percentAbsence'] = lyr.percentAbsence
         except:
            try:
               lyrVals['isOrganism'] = False
               lyrVals['attrValue'] = lyr.attrValue
               lyrVals['weightedMean'] = lyr.weightedMean
               lyrVals['largestClass'] = lyr.largestClass
               lyrVals['minPercent'] = lyr.minPercent
            except:
               raise Exception('Must provide PA or Anc Layer')
         layers[lyr.index] = lyrVals
      
      return layers, shapegrid
   
   # ...................................
   def _doWork(self):
      self.status, self.layerArrays = intersect(self.layers, self.shapegrid, 
                                           self.env, outputDir=self.outputPath)
   
   # .......................................
   def _push(self):
      """
      @summary: Pushes the results of the job to the job server
      """
      if self.status < JobStatus.GENERAL_ERROR:
         self.status = JobStatus.PUSH_REQUESTED
         component = "pam"
         contentType = "application/zip"
         
         # Initialize XML document
         lyrEl = Element("layers")
         
         # Initialize zip file
         outStream = StringIO()
         with zipfile.ZipFile(outStream, 'w') as zf:
            # Write log file
            zf.write(self.jobLogFile, os.path.split(self.jobLogFile)[1])
            
            for key in self.layerArrays.keys():
               fullFilePath = self.layerArrays[key]
               fn = os.path.split(fullFilePath)[1]
               # Add layer entry to XML
               el = SubElement(lyrEl, "layer")
               SubElement(el, "index", value=key)
               SubElement(el, "filename", value=fn)
               zf.write(fullFilePath, fn)
            
            # Write XML file
            xmlString = StringIO(tostring(lyrEl))
            xmlString.seek(0)
            zf.writestr("layerIndex.xml", xmlString.getvalue())

         outStream.seek(0)
         content = outStream.getvalue()
         try:
            self.env.postJob(self.PROCESS_TYPE, self.job.jobId, content, 
                                contentType, component)
            self.status = JobStatus.COMPLETE
            self._update()
         except Exception, e:
            try:
               self.log.debug(str(e))
            except: # Log not initialized
               pass
            self.status = JobStatus.PUSH_FAILED
            self._update()
      else:
         component = "error"
         content = None

   # ...................................
   def _cleanUp(self):
      """
      @summary: Cleans up after a job has completed.  This should deleting all
                   files created by the job that do not need to be kept on the
                   node.
      """
      try: # Output some extra logging information
         self.log.debug("Job end time: %s" % self.endTime)
      except Exception, e:
         print str(e)
         #pass
      try:
         import shutil
         STORE_LOGS = self.env.config.getboolean('options', 'Store Log Files')
         LOG_LOCATION = self.env.config.get('options', 'Log Storage Location')
         if STORE_LOGS:
            shutil.move(self.jobLogFile, os.path.join(LOG_LOCATION, 
                                            os.path.basename(self.jobLogFile)))
         shutil.rmtree(self.outputPath)#, ignore_errors=True)
      except:
         pass
   
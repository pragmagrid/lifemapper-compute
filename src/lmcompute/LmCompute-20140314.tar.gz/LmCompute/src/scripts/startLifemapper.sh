#!/bin/bash

sh $LM_SCRIPTS_PATH/lmJobSubmitter.sh &
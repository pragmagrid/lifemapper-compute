"""
@summary: Simple script that submits jobs
@author: CJ Grady
@version: 2.0
@status: alpha

@license: gpl2
@copyright: Copyright (C) 2014, University of Kansas Center for Research

          Lifemapper Project, lifemapper [at] ku [dot] edu, 
          Biodiversity Institute,
          1345 Jayhawk Boulevard, Lawrence, Kansas, 66045, USA
   
          This program is free software; you can redistribute it and/or modify 
          it under the terms of the GNU General Public License as published by 
          the Free Software Foundation; either version 2 of the License, or (at 
          your option) any later version.
  
          This program is distributed in the hope that it will be useful, but 
          WITHOUT ANY WARRANTY; without even the implied warranty of 
          MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
          General Public License for more details.
  
          You should have received a copy of the GNU General Public License 
          along with this program; if not, write to the Free Software 
          Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 
          02110-1301, USA.
"""
import ConfigParser
from getpass import getuser
import os
from time import sleep

from LmCompute.common.jobClient import LmJobClient, RemoteKillException

class JobSubmitter(object):
   """
   @summary: Job submitter class that reads a configuration file and then 
                operates accordingly
   """
   # ..................................
   def __init__(self, configFilename='submitterConfig.ini'):
      """
      @param configFilename: (optional) The name of a configuration file to use
      """
      # Read options
      self.readConfiguration(configFilename)

      # Initialize job client
      self.cl = LmJobClient()
      
   # ..................................
   def readConfiguration(self, configFilename):
      """
      @summary: Gets the configuration options from a configuration file
      @param configFilename: The name of the file to read the configuration from
      """
      self.config = ConfigParser.SafeConfigParser({'USER': getuser()})
      self.config.read(configFilename)

      # Read options
      self.killFile = self.config.get('options', 'KILL_FILE')
      self.queueSize = self.config.getint('options', 'QUEUE_SIZE')
      self.sleepTime = self.config.getint('options', 'SLEEP_TIME')
      self.controllerSleepTime = self.config.getint('options', 
                                                       'CONTROLLER_SLEEP_TIME')
      self.availJobsCheckInterval = self.config.getint('options', 
                                               'AVAILABLE_JOBS_CHECK_INTERVAL')
      self.numJobsThreshold = self.config.getint('options', 
                                                          'NUM_JOBS_THRESHOLD')
      self.versionCheckInterval = self.config.getint('options', 
                                                      'VERSION_CHECK_INTERVAL')
      self.jobLogging = self.config.getboolean('options', 'LOGGING')
      if self.jobLogging:
         self.jobSubmitCmd = self.config.get('job submit', 'CMD')
      else:
         self.jobSubmitCmd = self.config.get('job submit', 'CMD_NO_LOG')
      
      self.numJobsCmd = self.config.get('number of running jobs', 'CMD')

   # ..................................
   def checkAvailableJobs(self):
      """
      @summary: Checks to see if there are any available jobs for computation
      @return: Boolean indicating if there are available jobs
      """
      try:
         return self.cl.availableJobs(threshold=self.numJobsThreshold)
      except Exception, e:
         print "Request for available jobs failed: %s" % str(e)
         return False

   # ..................................
   def checkClientVersion(self):
      """
      @summary: Checks that the version of the client is not out of date
      """
      try:
         self.cl.checkVersion()
      except RemoteKillException, e:
         print "Client out of date, stopping..."
         raise e

   # ..................................
   def getNumberOfRunningProcesses(self):
      """
      @summary: Determines the number of running processes
      """
      res = os.popen(self.numJobsCmd)
      resp = res.read()
      if len(resp) == 0:
         return 0
      else:
         return int(resp)

   # ..................................
   def run(self):
      """
      @summary: Runs the job submitter
      """
      if os.path.exists(self.killFile):
         os.remove(self.killFile)
      
      n = 1 # Number of times through job submission loop for available jobs
      v = 1 # Number of times through job submission loop for version
      self.checkClientVersion() # Check client version on start
      
      while not os.path.exists(self.killFile):
         if v >= self.versionCheckInterval:
            v = 1
            self.checkClientVersion()
         else:
            v = v + 1
   
         if n >= self.availJobsCheckInterval:
            if not self.checkAvailableJobs():
               print "No available jobs, extended sleep"
               sleep(self.controllerSleepTime)
            else:
               n = 1
         else:
            n = n + 1
            numToSubmit = self.queueSize - self.getNumberOfRunningProcesses()
            print "Need to submit {0} processes".format(numToSubmit)
            if numToSubmit < 0:
               numToSubmit = 0
            for i in range(numToSubmit):
               print "Submitting job"
               res = os.popen(self.jobSubmitCmd)
               res.close()
            # Sleep
            print "Sleep"
            sleep(self.sleepTime)
   
      print "Done"
   
   # ..................................
   def stop(self):
      """
      @summary: Attempts to stop a job submitter by touching a file
      @todo: This method may not work in all cases
      """
      try:
         os.utime(self.killFile, None)
      except Exception, e:
         print str(e)
         print 
         print "Could not touch kill file, try manually creating:", self.killFile
   
# .............................................................................
if __name__ == "__main__":
   import sys
   
   cmd = "start"
   configFn = None
   
   if len(sys.argv) > 1:
      temp = sys.argv[1].strip()
      if temp.lower == 'stop':
         cmd = 'stop'
      else:
         configFn = temp
   if len(sys.argv) > 2:
      cmd = sys.argv[2].strip().lower()
   
   try:
      if os.path.exists(configFn):
         jobSubmitter = JobSubmitter(configFn)
      else:
         print "Configuration file:", configFn, "does not exist"
         raise Exception, "Configuration file not found"
   except:
      jobSubmitter = JobSubmitter()
   
   if cmd == 'stop':
      print "Stopping job submitter"
      jobSubmitter.stop()
   else:
      print "Starting job submitter"
      jobSubmitter.run()
   

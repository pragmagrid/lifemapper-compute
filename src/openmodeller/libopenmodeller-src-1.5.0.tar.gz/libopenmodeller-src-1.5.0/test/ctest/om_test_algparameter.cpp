/* Generated file, do not edit */

#ifndef CXXTEST_RUNNING
#define CXXTEST_RUNNING
#endif

#define _CXXTEST_HAVE_STD
#include <cxxtest/TestListener.h>
#include <cxxtest/TestTracker.h>
#include <cxxtest/TestRunner.h>
#include <cxxtest/RealDescriptions.h>
#include <cxxtest/ErrorPrinter.h>

int main() {
 return CxxTest::ErrorPrinter().run();
}
#include "om_test_algparameter.h"

static test_AlgParameter suite_test_AlgParameter;

static CxxTest::List Tests_test_AlgParameter = { 0, 0 };
CxxTest::StaticSuiteDescription suiteDescription_test_AlgParameter( "om_test_algparameter.h", 38, "test_AlgParameter", suite_test_AlgParameter, Tests_test_AlgParameter );

static class TestDescription_test_AlgParameter_test1 : public CxxTest::RealTestDescription {
public:
 TestDescription_test_AlgParameter_test1() : CxxTest::RealTestDescription( Tests_test_AlgParameter, suiteDescription_test_AlgParameter, 85, "test1" ) {}
 void runTest() { suite_test_AlgParameter.test1(); }
} testDescription_test_AlgParameter_test1;

static class TestDescription_test_AlgParameter_test2 : public CxxTest::RealTestDescription {
public:
 TestDescription_test_AlgParameter_test2() : CxxTest::RealTestDescription( Tests_test_AlgParameter, suiteDescription_test_AlgParameter, 91, "test2" ) {}
 void runTest() { suite_test_AlgParameter.test2(); }
} testDescription_test_AlgParameter_test2;

static class TestDescription_test_AlgParameter_test3 : public CxxTest::RealTestDescription {
public:
 TestDescription_test_AlgParameter_test3() : CxxTest::RealTestDescription( Tests_test_AlgParameter, suiteDescription_test_AlgParameter, 97, "test3" ) {}
 void runTest() { suite_test_AlgParameter.test3(); }
} testDescription_test_AlgParameter_test3;

static class TestDescription_test_AlgParameter_test4 : public CxxTest::RealTestDescription {
public:
 TestDescription_test_AlgParameter_test4() : CxxTest::RealTestDescription( Tests_test_AlgParameter, suiteDescription_test_AlgParameter, 103, "test4" ) {}
 void runTest() { suite_test_AlgParameter.test4(); }
} testDescription_test_AlgParameter_test4;

static class TestDescription_test_AlgParameter_test5 : public CxxTest::RealTestDescription {
public:
 TestDescription_test_AlgParameter_test5() : CxxTest::RealTestDescription( Tests_test_AlgParameter, suiteDescription_test_AlgParameter, 112, "test5" ) {}
 void runTest() { suite_test_AlgParameter.test5(); }
} testDescription_test_AlgParameter_test5;

static class TestDescription_test_AlgParameter_test6 : public CxxTest::RealTestDescription {
public:
 TestDescription_test_AlgParameter_test6() : CxxTest::RealTestDescription( Tests_test_AlgParameter, suiteDescription_test_AlgParameter, 120, "test6" ) {}
 void runTest() { suite_test_AlgParameter.test6(); }
} testDescription_test_AlgParameter_test6;

static class TestDescription_test_AlgParameter_test7 : public CxxTest::RealTestDescription {
public:
 TestDescription_test_AlgParameter_test7() : CxxTest::RealTestDescription( Tests_test_AlgParameter, suiteDescription_test_AlgParameter, 128, "test7" ) {}
 void runTest() { suite_test_AlgParameter.test7(); }
} testDescription_test_AlgParameter_test7;

static class TestDescription_test_AlgParameter_test8 : public CxxTest::RealTestDescription {
public:
 TestDescription_test_AlgParameter_test8() : CxxTest::RealTestDescription( Tests_test_AlgParameter, suiteDescription_test_AlgParameter, 136, "test8" ) {}
 void runTest() { suite_test_AlgParameter.test8(); }
} testDescription_test_AlgParameter_test8;

#include <cxxtest/Root.cpp>

#include <iostream>
int main( int argc, char **argv ) 
{
std::cout << argv[argc-1] << std::endl;
  return 1;
}


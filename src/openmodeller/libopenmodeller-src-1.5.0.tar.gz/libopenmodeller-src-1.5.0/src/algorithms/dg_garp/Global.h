#ifndef __GLOBAL_H__
#define __GLOBAL_H__

// ===================================================================
// compilation fags
// ===================================================================
// link ESRI GRIDIO library to code
#define __GRIDIO

// windows (GARPWIN)
#define __GARPWIN

// ===================================================================

#endif

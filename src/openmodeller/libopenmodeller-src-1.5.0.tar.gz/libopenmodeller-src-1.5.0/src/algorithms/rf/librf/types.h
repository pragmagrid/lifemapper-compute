#ifndef _TYPES_H_
#define _TYPES_H_

namespace librf {

typedef unsigned int uint32;
typedef unsigned short uint16;
typedef unsigned char uchar;
typedef unsigned char byte;

} // namespace
#endif

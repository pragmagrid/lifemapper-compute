#include "librf/discrete_dist.h"
#include <math.h>
namespace librf {

const float DiscreteDist::kLog2 = log((float)2.0);

} // namespace

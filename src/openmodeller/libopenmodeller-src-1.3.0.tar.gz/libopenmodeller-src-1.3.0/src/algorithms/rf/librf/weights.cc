#include "librf/weights.h"
using namespace librf;

int main(int argc, char* argv[]) {
  weight_list w(100, 100);


  return 0;
}


/**
* Declaration of class PreParameters
*
* @author Missae Yamamoto (missae at dpi . inpe . br)
* $Id: PreParameters.cpp 4464 2008-07-08 20:26:41Z missae $
*
* LICENSE INFORMATION
* 
* Copyright(c) 2008 by INPE -
* Instituto Nacional de Pesquisas Espaciais
*
* http://www.inpe.br
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.
* 
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details:
* 
* http://www.gnu.org/copyleft/gpl.html
*/

#include "PreParameters.hh"

PreParameters::PreParameters()
{
}

PreParameters::~PreParameters()
{
}
std::string PreParameters::decName() const
{
  std::string return_string;
  
  throw;
  
  return return_string;
}

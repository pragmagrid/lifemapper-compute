<!-- Tufts VUE 3.0.2 concept-map (ws_diagram.vue) 2012-01-19 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/usr/local/src/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Thu Jan 19 10:30:42 BRST 2012 by renato on platform Linux 2.6.32-37-generic in JVM 1.5.0_07-b03 -->
<!-- Do Not Remove: Saving version @(#)VUE: built July 1 2010 at 1436 by vue on Linux 2.4.21-57.EL i386 JVM 1.5.0_06-b05(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0" label="ws_diagram.vue"
    created="1317671662490" x="0.0" y="0.0" width="1.4E-45"
    height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1326976242885" size="87579"
        spec="/home/renato/projects/openmodeller/subversion/framework/doc/ws_diagram.vue"
        type="1" xsi:type="URLResource">
        <title>ws_diagram.vue</title>
        <property key="File" value="/home/renato/projects/openmodeller/subversion/framework/doc/ws_diagram.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <metadata-list category-list-size="1" other-list-size="0"
        ontology-list-size="0" RCategoryListSize="0">
        <ontology-list-string></ontology-list-string>
        <metadata xsi:type="vue-metadata-element">
            <value></value>
            <key>http://vue.tufts.edu/vue.rdfs#none</key>
            <type>1</type>
        </metadata>
    </metadata-list>
    <URIString>http://vue.tufts.edu/rdf/resource/cb6030007f00010100ed3b53db0e8815</URIString>
    <child ID="6" label="createModel" layerID="1"
        created="1317671681130" x="-369.0" y="252.77574" width="136.0"
        height="51.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb6030037f00010100ed3b53a95e37c0</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="7" label="getProgress" layerID="1"
        created="1317671707629" x="-366.0" y="340.77576" width="130.0"
        height="47.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb6030147f00010100ed3b5335557033</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="8" label="Aborted?" layerID="1" created="1317671797154"
        x="-348.0" y="459.77576" width="96.0" height="46.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb6030247f00010100ed3b53f0380832</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="9" layerID="1" created="1317671841175" x="-301.3017"
        y="387.27734" width="1.6083984" height="73.09375"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb6030267f00010100ed3b5332648223</URIString>
        <point1 x="-300.8017" y="387.77734"/>
        <point2 x="-300.1933" y="459.8711"/>
        <ID1 xsi:type="node">7</ID1>
        <ID2 xsi:type="node">8</ID2>
    </child>
    <child ID="10" label="getLog" layerID="1" created="1317671892019"
        x="-176.0" y="454.2757" width="130.0" height="47.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb60302a7f00010100ed3b53e4c4acbf</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="11" label="no" layerID="1" created="1317671987967"
        x="-493.15182" y="364.01724" width="146.05988"
        height="206.20401" strokeWidth="1.0" autoSized="false"
        controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb60302e7f00010100ed3b538aff8089</URIString>
        <point1 x="-347.59195" y="569.72125"/>
        <point2 x="-366.0" y="364.51724"/>
        <ID1 xsi:type="node">45</ID1>
        <ID2 xsi:type="node">7</ID2>
        <ctrlPoint0 x="-546.94714" y="570.5403" xsi:type="point"/>
        <ctrlPoint1 x="-511.59375" y="365.05814" xsi:type="point"/>
    </child>
    <child ID="12" layerID="1" created="1317672171336" x="-301.5"
        y="303.27576" width="1.0" height="38.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb79791b7f00010100ed3b53636ccda9</URIString>
        <point1 x="-301.0" y="303.77576"/>
        <point2 x="-301.0" y="340.77576"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <child ID="13" label="ping" layerID="1" created="1317672194003"
        x="-367.0" y="-180.72429" width="130.0" height="47.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb79791d7f00010100ed3b5301d66dd4</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="14" label="service is&#xa;running?" layerID="1"
        created="1317672228015" x="-354.0" y="-97.22429" width="103.8"
        height="72.8" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb79791e7f00010100ed3b5336b07237</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="15" layerID="1" created="1317672285135" x="-302.56226"
        y="-134.21875" width="1.0379028" height="37.53125"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb7979207f00010100ed3b532050c490</URIString>
        <point1 x="-302.02435" y="-133.71875"/>
        <point2 x="-302.06226" y="-97.1875"/>
        <ID1 xsi:type="node">13</ID1>
        <ID2 xsi:type="node">14</ID2>
    </child>
    <child ID="16" label="poke sysadmin" layerID="1"
        created="1317672337952" x="-201.0" y="-84.72429" width="130.0"
        height="47.0" strokeWidth="1.0" strokeStyle="4"
        autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb7979827f00010100ed3b53318e8c3f</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="17" label="no" layerID="1" created="1317672383891"
        x="-250.8776" y="-68.0083" width="50.377594" height="14.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb7979867f00010100ed3b5361a87796</URIString>
        <point1 x="-250.3776" y="-60.948845"/>
        <point2 x="-201.0" y="-61.067757"/>
        <ID1 xsi:type="node">14</ID1>
        <ID2 xsi:type="node">16</ID2>
    </child>
    <child ID="18" label="getAlgorithms" layerID="1"
        created="1317672408289" x="-458.0" y="62.27571" width="130.0"
        height="47.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb7979887f00010100ed3b53e85e219e</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="19" label="getLayers" layerID="1" created="1317672581220"
        x="-276.0" y="62.27571" width="130.0" height="47.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb7979897f00010100ed3b53b32e49ee</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="23" label="yes" layerID="1" created="1317672774207"
        x="-310.2968" y="-25.279297" width="18.0" height="43.26111"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb7979a67f00010100ed3b53303dac87</URIString>
        <point1 x="-301.59366" y="-24.779297"/>
        <point2 x="-301.0" y="17.481812"/>
        <ID1 xsi:type="node">14</ID1>
        <ID2 xsi:type="link">38</ID2>
    </child>
    <child ID="24" layerID="1" created="1317672791487" x="-301.5"
        y="16.981812" width="60.0309" height="45.7939" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb7979a77f00010100ed3b534da119e1</URIString>
        <point1 x="-301.0" y="17.481812"/>
        <point2 x="-241.9691" y="62.27571"/>
        <ID1 xsi:type="link">38</ID1>
        <ID2 xsi:type="node">19</ID2>
    </child>
    <child ID="25" label="choose algorithm&#xa;and set parameters"
        layerID="1" created="1317674033547" x="-457.0" y="164.27573"
        width="130.0" height="47.0" strokeWidth="1.0" strokeStyle="4"
        autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb81c9df7f00010100ed3b530457066c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="26" layerID="1" created="1317674059431" x="-393.26962"
        y="108.77734" width="1.5392456" height="56.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb81c9e17f00010100ed3b53b7932c0b</URIString>
        <point1 x="-392.76962" y="109.27734"/>
        <point2 x="-392.23038" y="164.27734"/>
        <ID1 xsi:type="node">18</ID1>
        <ID2 xsi:type="node">25</ID2>
    </child>
    <child ID="27" label="choose layers" layerID="1"
        created="1317674074328" x="-277.0" y="164.27573" width="130.0"
        height="47.0" strokeWidth="1.0" strokeStyle="4"
        autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb81c9e27f00010100ed3b53eb074518</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="28" layerID="1" created="1317674092422" x="-212.2696"
        y="108.77539" width="1.5392151" height="56.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb81c9e37f00010100ed3b53bd6178e8</URIString>
        <point1 x="-211.2304" y="109.27539"/>
        <point2 x="-211.7696" y="164.27539"/>
        <ID1 xsi:type="node">19</ID1>
        <ID2 xsi:type="node">27</ID2>
    </child>
    <child ID="29"
        label="(you may want to cache these results on the client)"
        layerID="1" created="1317674112196" x="-372.0" y="118.77571"
        width="146.0" height="33.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb81c9e67f00010100ed3b5385c9cbea</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000; text-align: center" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;(you may want to cache &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000; text-align: center" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;these results on the client)&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>(you may want to cache these results on the client)</label>
    </child>
    <child ID="30" label="provide training&#xa;points" layerID="1"
        created="1317674233548" x="-571.0" y="254.27574" width="130.0"
        height="47.0" strokeWidth="1.0" strokeStyle="4"
        autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb81c9ea7f00010100ed3b536a000aab</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="31" label="Faults: * No available algorithms" layerID="1"
        created="1317925419927" x="-591.0" y="65.52571" width="125.0"
        height="31.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/da8e906c7f0001010163c5bb92588b37</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* No available algorithms&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * No available algorithms</label>
    </child>
    <child ID="33" layerID="1" created="1317925612466" x="-441.5"
        y="277.4343" width="73.0" height="1.1755981" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/da8e906f7f0001010163c5bbed004f2f</URIString>
        <point1 x="-441.0" y="277.9343"/>
        <point2 x="-369.0" y="278.1099"/>
        <ID1 xsi:type="node">30</ID1>
        <ID2 xsi:type="node">6</ID2>
    </child>
    <child ID="34" layerID="1" created="1317925618346" x="-368.87018"
        y="210.77573" width="42.72934" height="42.50003"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/da8e90727f0001010163c5bb15609f81</URIString>
        <point1 x="-368.37018" y="211.27573"/>
        <point2 x="-326.64084" y="252.77576"/>
        <ID1 xsi:type="node">25</ID1>
        <ID2 xsi:type="node">6</ID2>
    </child>
    <child ID="35" layerID="1" created="1317925624042" x="-276.42264"
        y="210.77573" width="41.81215" height="42.500015"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/da8e90737f0001010163c5bb47732e21</URIString>
        <point1 x="-235.11049" y="211.27573"/>
        <point2 x="-275.92264" y="252.77574"/>
        <ID1 xsi:type="node">27</ID1>
        <ID2 xsi:type="node">6</ID2>
    </child>
    <child ID="39" layerID="1" created="1317926424466" x="-361.8427"
        y="16.981812" width="61.342712" height="45.7939"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/da8e90787f0001010163c5bbd5be661c</URIString>
        <point1 x="-301.0" y="17.481812"/>
        <point2 x="-361.3427" y="62.27571"/>
        <ID1 xsi:type="link">38</ID1>
        <ID2 xsi:type="node">18</ID2>
    </child>
    <child ID="38" layerID="1" created="1317926362538" x="-347.0"
        y="15.437912" width="92.0" height="4.087799" strokeWidth="4.0"
        autoSized="false" controlCount="0" arrowState="0" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/da8e907b7f0001010163c5bb86b8b90d</URIString>
        <point1 x="-345.0" y="17.437912"/>
        <point2 x="-257.0" y="17.525711"/>
    </child>
    <child ID="40"
        label="Faults: * Cache manipulation error (1,2,3,4) * Could not read available layers Note: Layers must exist on the server as they can be huge files"
        layerID="1" created="1317926484959" x="-137.5" y="63.02571"
        width="179.0" height="72.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/da8e907c7f0001010163c5bb24fd5ec4</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Cache manipulation error (1,2,3,4) &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Could not read available layers &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;u&gt;&lt;font style="font-size:10;"&gt;Note: Layers must exist on the server as 
      they can be huge files&lt;/font&gt;&lt;/u&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * Cache manipulation error (1,2,3,4) * Could not read available layers Note: Layers must exist on the server as they can be huge files</label>
    </child>
    <child ID="41" label="Faults: * Failed to create ticket (1,2,3,4,5)"
        layerID="1" created="1317927646491" x="-225.5" y="256.02576"
        width="173.0" height="32.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daad03ff7f0001010163c5bbda5bf684</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Failed to create ticket (1,2,3,4,5)&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * Failed to create ticket (1,2,3,4,5)</label>
    </child>
    <child ID="42" label="testModel" layerID="1" created="1317928032219"
        x="-517.0" y="801.0257" width="136.0" height="51.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daad04017f0001010163c5bb5553c5d2</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="43" label="projectModel" layerID="1"
        created="1317928045915" x="-218.0" y="801.0257" width="136.0"
        height="51.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daad04047f0001010163c5bb070e44e0</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="44"
        label="Faults: * Missing ticket in request * Progress unreadable Status: -1 => queued -2 => aborted [0, 100) => in progress 100 => finished"
        layerID="1" created="1317928154329" x="-224.5" y="340.52576"
        width="173.0" height="107.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daad040b7f0001010163c5bbbfec0af2</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Missing ticket in request &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Progress unreadable &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Status: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;-1 =&amp;gt; queued &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;-2 =&amp;gt; aborted &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;[0, 100) =&amp;gt; in progress &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;100 =&amp;gt; finished&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * Missing ticket in request * Progress unreadable Status: -1 =&gt; queued -2 =&gt; aborted [0, 100) =&gt; in progress 100 =&gt; finished</label>
    </child>
    <child ID="45" label="Finished?" layerID="1" created="1317928452971"
        x="-348.0" y="546.52576" width="96.0" height="46.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daad040e7f0001010163c5bb10ce85b2</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="46" label="no" layerID="1" created="1317928478954"
        x="-307.0" y="505.27576" width="14.0" height="41.75"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daad040f7f0001010163c5bb2749d0bf</URIString>
        <point1 x="-300.0" y="505.77576"/>
        <point2 x="-300.0" y="546.52576"/>
        <ID1 xsi:type="node">8</ID1>
        <ID2 xsi:type="node">45</ID2>
    </child>
    <child ID="47" label="yes" layerID="1" created="1317928622712"
        x="-255.01147" y="473.5338" width="79.51149" height="14.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daad04147f0001010163c5bbcf31710e</URIString>
        <point1 x="-254.51149" y="481.57233"/>
        <point2 x="-176.0" y="479.4953"/>
        <ID1 xsi:type="node">8</ID1>
        <ID2 xsi:type="node">10</ID2>
    </child>
    <child ID="48"
        label="Faults: * Missing ticket in request * Log unavailable"
        layerID="1" created="1317928694837" x="-33.5" y="453.5257"
        width="138.0" height="44.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daad04197f0001010163c5bb3a8de5d6</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Missing ticket in request &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Log unavailable&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * Missing ticket in request * Log unavailable</label>
    </child>
    <child ID="49" label="getModel" layerID="1" created="1317928770712"
        x="-368.0" y="636.02576" width="136.0" height="51.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daaefa787f0001010163c5bb67bfe48f</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="50" label="yes" layerID="1" created="1317928798106"
        x="-309.0" y="592.02576" width="18.0" height="44.5"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daaefa797f0001010163c5bb585c9e88</URIString>
        <point1 x="-300.0" y="592.52576"/>
        <point2 x="-300.0" y="636.02576"/>
        <ID1 xsi:type="node">45</ID1>
        <ID2 xsi:type="node">49</ID2>
    </child>
    <child ID="51"
        label="Faults: * Missing ticket in request * Model unavailable Note: Result is a mathematical representation in XML. Each algorithm has its own representation."
        layerID="1" created="1317928818595" x="-222.5" y="635.52576"
        width="158.0" height="96.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/daaefa7a7f0001010163c5bb9f94d424</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Missing ticket in request &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Model unavailable &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;u&gt;&lt;font style="font-size:10;"&gt;Note: Result is a mathematical 
      representation in XML. Each algorithm has its own representation.&lt;/font&gt;&lt;/u&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * Missing ticket in request * Model unavailable Note: Result is a mathematical representation in XML. Each algorithm has its own representation.</label>
    </child>
    <child ID="52" label="provide testing&#xa;points" layerID="1"
        created="1317928965720" x="-514.0" y="711.0256" width="130.0"
        height="47.0" strokeWidth="1.0" strokeStyle="4"
        autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dab076ff7f0001010163c5bb664eb365</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="53" label="getLayerAsUrl" layerID="1"
        created="1317929012574" x="-364.0" y="1074.0258" width="136.0"
        height="51.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610547f0001010163c5bb766723f0</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="54" label="getTestResult" layerID="1"
        created="1317929034432" x="-517.39996" y="979.0257"
        width="136.0" height="51.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610557f0001010163c5bbf588e80b</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="55" label="getProjectionMetadata" layerID="1"
        created="1317929071825" x="-61.0" y="1074.0258" width="140.0"
        height="51.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610567f0001010163c5bb0e50665c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="56" label="Faults: * Failed to create ticket (1,2,3,4,5)"
        layerID="1" created="1317929534710" x="-72.5" y="800.5257"
        width="124.0" height="42.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610577f0001010163c5bb70bcb7e2</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Failed to create ticket &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;(1,2,3,4,5)&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * Failed to create ticket (1,2,3,4,5)</label>
    </child>
    <child ID="57" label="Faults: * Failed to create ticket (1,2,3,4,5)"
        layerID="1" created="1317929579142" x="-371.5" y="800.5257"
        width="123.0" height="42.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610587f0001010163c5bb83f4fbeb</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Failed to create ticket &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;(1,2,3,4,5)&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * Failed to create ticket (1,2,3,4,5)</label>
    </child>
    <child ID="60"
        label="Faults: * Missing id in request * Layer unavailable"
        layerID="1" created="1317929820476" x="-218.5" y="1073.5258"
        width="136.0" height="55.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac6105d7f0001010163c5bb82a94596</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Missing id in request&lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Layer unavailable&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * Missing id in request * Layer unavailable</label>
    </child>
    <child ID="61"
        label="Faults: * Missing ticket in request * Projection unavailable * Projection unreadable * Metadata unavailable"
        layerID="1" created="1317930001288" x="89.0" y="1073.5258"
        width="136.0" height="70.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac6105e7f0001010163c5bb35db7abc</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Missing ticket in request &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Projection unavailable &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Projection unreadable &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Metadata unavailable&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * Missing ticket in request * Projection unavailable * Projection unreadable * Metadata unavailable</label>
    </child>
    <child ID="62"
        label="Faults: * Missing ticket in request * Test result unavailable"
        layerID="1" created="1317930048493" x="-370.0" y="981.5257"
        width="136.0" height="42.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610607f0001010163c5bb55fa6032</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Missing ticket in request &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Test result unavailable&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: * Missing ticket in request * Test result unavailable</label>
    </child>
    <child ID="63" label="getProgress&#xa;procedure" layerID="1"
        created="1317930125999" x="-213.0" y="893.02563" width="130.0"
        height="47.0" strokeWidth="1.0" strokeStyle="4"
        autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610637f0001010163c5bb032f568d</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="64" label="getProgress&#xa;procedure" layerID="1"
        created="1317930179307" x="-514.0" y="893.02563" width="130.0"
        height="47.0" strokeWidth="1.0" strokeStyle="4"
        autoSized="false" xsi:type="node">
        <fillColor>#EEEEEE</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610647f0001010163c5bb2ae60ee4</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="65" layerID="1" created="1317930225502" x="-148.23431"
        y="939.5254" width="1.7343292" height="65.95642"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610657f0001010163c5bb84b73df9</URIString>
        <point1 x="-147.73433" y="940.0254"/>
        <point2 x="-147.0" y="1004.9818"/>
        <ID1 xsi:type="node">63</ID1>
        <ID2 xsi:type="link">80</ID2>
    </child>
    <child ID="66" layerID="1" created="1317930232186" x="-147.5"
        y="1004.4818" width="114.92435" height="70.043945"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610667f0001010163c5bb54629ea7</URIString>
        <point1 x="-147.0" y="1004.9818"/>
        <point2 x="-33.075657" y="1074.0258"/>
        <ID1 xsi:type="link">80</ID1>
        <ID2 xsi:type="node">55</ID2>
    </child>
    <child ID="67" layerID="1" created="1317930237548" x="-449.78403"
        y="939.52344" width="1.1772461" height="40.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610667f0001010163c5bb541360f8</URIString>
        <point1 x="-449.10678" y="940.02344"/>
        <point2 x="-449.28403" y="979.02344"/>
        <ID1 xsi:type="node">64</ID1>
        <ID2 xsi:type="node">54</ID2>
    </child>
    <child ID="68" layerID="1" created="1317930242130" x="-149.93335"
        y="851.5259" width="1.9111176" height="42.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610677f0001010163c5bbe4ded1bc</URIString>
        <point1 x="-149.43333" y="852.0259"/>
        <point2 x="-148.52222" y="893.0259"/>
        <ID1 xsi:type="node">43</ID1>
        <ID2 xsi:type="node">63</ID2>
    </child>
    <child ID="69" layerID="1" created="1317930246130" x="-449.5"
        y="851.52563" width="1.0" height="41.99994" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610687f0001010163c5bb707563bd</URIString>
        <point1 x="-449.0" y="852.0257"/>
        <point2 x="-449.0" y="893.02563"/>
        <ID1 xsi:type="node">42</ID1>
        <ID2 xsi:type="node">64</ID2>
    </child>
    <child ID="70" layerID="1" created="1317930285091" x="-300.5"
        y="686.52576" width="1.0" height="50.205994" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac610697f0001010163c5bb06b04025</URIString>
        <point1 x="-300.0" y="687.02576"/>
        <point2 x="-300.0" y="736.23175"/>
        <ID1 xsi:type="node">49</ID1>
        <ID2 xsi:type="link">75</ID2>
    </child>
    <child ID="71" layerID="1" created="1317930291419" x="-407.42072"
        y="735.73175" width="107.920715" height="65.793945"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac6106a7f0001010163c5bb8cc2d71a</URIString>
        <point1 x="-300.0" y="736.23175"/>
        <point2 x="-406.92072" y="801.0257"/>
        <ID1 xsi:type="link">75</ID1>
        <ID2 xsi:type="node">42</ID2>
    </child>
    <child ID="72" layerID="1" created="1317930372251" x="-449.5"
        y="757.5256" width="1.0" height="44.000122" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac6106b7f0001010163c5bb37557ac8</URIString>
        <point1 x="-449.0" y="758.0256"/>
        <point2 x="-449.0" y="801.0257"/>
        <ID1 xsi:type="node">52</ID1>
        <ID2 xsi:type="node">42</ID2>
    </child>
    <child ID="74" label="getProgress procedure" layerID="1"
        created="1317930520521" x="-31.0" y="311.52573" width="140.0"
        height="21.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dac854c47f0001010163c5bbff8605db</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      getProgress procedure
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>getProgress procedure</label>
    </child>
    <child ID="76" layerID="1" created="1317931403562" x="-300.5"
        y="735.73175" width="108.63835" height="65.793945"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dada962f7f0001010163c5bb33d70547</URIString>
        <point1 x="-300.0" y="736.23175"/>
        <point2 x="-192.36165" y="801.0257"/>
        <ID1 xsi:type="link">75</ID1>
        <ID2 xsi:type="node">43</ID2>
    </child>
    <child ID="75" layerID="1" created="1317931332160" x="-346.0"
        y="734.1879" width="92.0" height="4.0876465" strokeWidth="4.0"
        autoSized="false" controlCount="0" arrowState="0" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dada96327f0001010163c5bb303bb23a</URIString>
        <point1 x="-344.0" y="736.1879"/>
        <point2 x="-256.0" y="736.2756"/>
    </child>
    <child ID="81" layerID="1" created="1317931625346" x="-256.31238"
        y="1004.4818" width="109.81236" height="70.043945"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dada96367f0001010163c5bb7b318020</URIString>
        <point1 x="-147.0" y="1004.9818"/>
        <point2 x="-255.81236" y="1074.0258"/>
        <ID1 xsi:type="link">80</ID1>
        <ID2 xsi:type="node">53</ID2>
    </child>
    <child ID="80" layerID="1" created="1317931539837" x="-193.0"
        y="1002.9379" width="92.0" height="4.0877686" strokeWidth="4.0"
        autoSized="false" controlCount="0" arrowState="0" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/dada96367f0001010163c5bb70125fa3</URIString>
        <point1 x="-191.0" y="1004.9379"/>
        <point2 x="-103.0" y="1005.0257"/>
    </child>
    <child ID="82" layerID="1" created="1326907680378" x="-569.5"
        y="329.52573" width="674.0" height="295.99997" strokeWidth="1.0"
        strokeStyle="4" autoSized="false" xsi:type="node">
        <fillColor>#00000000</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f1de35e47f00010101c0ae7683de8765</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="83"
        label="Faults: &#xa;    &#xa;    &#xa;      * Missing configuration&#xa;    &#xa;    &#xa;      * No available algorithms"
        layerID="1" created="1326976055430" x="-227.2292" y="-181.5243"
        width="124.0" height="41.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>-plain-10</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f5f296487f0001010020463ea158430d</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { color: #000000; margin-bottom: 0px; margin-right: 0px; font-family: Arial; margin-left: 0px; font-size: 12; margin-top: 0px }
        ol { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
        p { color: #000000; margin-bottom: 0; margin-right: 0; margin-left: 0; margin-top: 0 }
        ul { font-family: Arial; list-style-position: outside; vertical-align: middle; margin-left: 30; margin-top: 6; font-size: 12 }
      --&gt;
    &lt;/style&gt;
        
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;Faults: &lt;/font&gt;
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* Missing configuration
&lt;/font&gt;    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:10;"&gt;* No available algorithms&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Faults: 
    
    
      * Missing configuration
    
    
      * No available algorithms</label>
    </child>
    <layer ID="1" label="Layer 1" created="1317671662505" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <metadata-list category-list-size="0" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/cb6030317f00010100ed3b53b68fa504</URIString>
    </layer>
    <userZoom>1.25</userZoom>
    <userOrigin x="-795.03656" y="-239.90538"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" created="1317671662486"
            x="0.0" y="0.0" width="1.4E-45" height="1.4E-45"
            strokeWidth="0.0" autoSized="false" currentIndex="0" open="true">
            <strokeColor>#B3993333</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="0" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/cb6030347f00010100ed3b53eb32c6b7</URIString>
            <masterSlide ID="2" created="1317671662567" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <metadata-list category-list-size="0"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/cb6030377f00010100ed3b5374626fdd</URIString>
                <titleStyle ID="3" label="Header"
                    created="1317671663092" x="332.5" y="174.5"
                    width="135.0" height="51.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/cb6030387f00010100ed3b539eb6224a</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="4" label="Slide Text"
                    created="1317671663129" x="342.0" y="283.0"
                    width="116.0" height="34.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/cb6030397f00010100ed3b537cd6151e</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="5" label="Links" created="1317671663133"
                    x="371.5" y="385.0" width="57.0" height="30.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <metadata-list category-list-size="0"
                        other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                        <ontology-list-string></ontology-list-string>
                    </metadata-list>
                    <URIString>http://vue.tufts.edu/rdf/resource/cb6030417f00010100ed3b5396325cf1</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2011-10-03</date>
    <mapFilterModel/>
    <modelVersion>5</modelVersion>
    <saveLocation>/home/renato/projects/openmodeller/subversion/framework/doc</saveLocation>
    <saveFile>/home/renato/projects/openmodeller/subversion/framework/doc/ws_diagram.vue</saveFile>
</LW-MAP>

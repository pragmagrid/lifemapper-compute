typedef struct {
	PyObject_HEAD
} PySpamObject;
